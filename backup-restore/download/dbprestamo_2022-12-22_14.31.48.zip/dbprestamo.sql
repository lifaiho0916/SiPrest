/*{------------------------------------------------------------------------
|  MySQL Database Backup DumpDB
|
|  Host: localhost    Database: dbprestamo    CreateAt: 2022-12-22 14:31:48
|
|  Server: version 10.4.22-MariaDB
|
|  Author of DumpDB: < gil_yeung@outlook.com > Gilberto Villarreal Rodriguez 
*-------------------------------------------------------------------------}*/
 

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;


-- ================================== BEGIN DATABASE dbprestamo =======================================
-- DROP DATABASE IF EXISTS `dbprestamo`;
-- CREATE DATABASE `dbprestamo`;
-- USE `dbprestamo`;

-- DROP TABLE tablename1, tablename2, tablename3, tablename4;


-- ----------------------------
-- Table structure for caja
-- ----------------------------
 
DROP TABLE IF EXISTS `caja`;
CREATE TABLE `caja` (
  `caja_id` int(11) NOT NULL AUTO_INCREMENT,
  `caja_descripcion` varchar(100) DEFAULT NULL,
  `caja_monto_inicial` float DEFAULT NULL,
  `caja_monto_ingreso` float DEFAULT NULL,
  `caja_prestamo` float DEFAULT NULL,
  `caja_f_apertura` date DEFAULT NULL,
  `caja_f_cierre` date DEFAULT NULL,
  `caja__monto_egreso` float DEFAULT NULL,
  `caja_monto_total` float DEFAULT NULL,
  `caja_estado` varchar(50) DEFAULT NULL,
  `caja_hora_apertura` time DEFAULT NULL,
  `caja_hora_cierre` time DEFAULT NULL,
  `caja_count_prestamo` varchar(100) DEFAULT NULL,
  `caja_count_ingreso` varchar(100) DEFAULT NULL,
  `caja_count_egreso` varchar(100) DEFAULT NULL,
  `caja_correo` varchar(100) DEFAULT NULL,
  `caja_interes` float DEFAULT NULL,
  PRIMARY KEY (`caja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table caja
-- ----------------------------
 
INSERT INTO `caja` (`caja_id`,`caja_descripcion`,`caja_monto_inicial`,`caja_monto_ingreso`,`caja_prestamo`,`caja_f_apertura`,`caja_f_cierre`,`caja__monto_egreso`,`caja_monto_total`,`caja_estado`,`caja_hora_apertura`,`caja_hora_cierre`,`caja_count_prestamo`,`caja_count_ingreso`,`caja_count_egreso`,`caja_correo`,`caja_interes`) VALUES
('7','Apertura de Caja','1000','0','1044','2022-12-21','2022-12-21','20','1124','CERRADO','13:04:30','14:14:44','2','0','1','',''),
('8','Apertura de Caja','500','0','236','2022-12-21','2022-12-21','0','536','CERRADO','14:24:46','14:26:25','1','0','0','','36'),
('9','Apertura de Caja','500','','','2022-12-21','','','','VIGENTE','14:28:15','','','','','','');

-- ----------------------------
-- Table structure for clientes
-- ----------------------------
 
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_nombres` varchar(255) DEFAULT NULL,
  `cliente_dni` varchar(50) DEFAULT NULL,
  `cliente_cel` varchar(20) DEFAULT NULL,
  `cliente_estado_prestamo` varchar(50) DEFAULT NULL,
  `cliente_direccion` varchar(255) DEFAULT NULL,
  `cliente_obs` varchar(255) DEFAULT NULL,
  `cliente_correo` varchar(255) DEFAULT NULL,
  `cliente_estatus` varchar(255) DEFAULT NULL,
  `cliente_cant_prestamo` char(10) DEFAULT NULL,
  `cliente_refe` varchar(255) DEFAULT NULL,
  `cliente_cel_refe` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cliente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table clientes
-- ----------------------------
 
INSERT INTO `clientes` (`cliente_id`,`cliente_nombres`,`cliente_dni`,`cliente_cel`,`cliente_estado_prestamo`,`cliente_direccion`,`cliente_obs`,`cliente_correo`,`cliente_estatus`,`cliente_cant_prestamo`,`cliente_refe`,`cliente_cel_refe`) VALUES
('1','marga','454545','99945233','','sullana la nueva','','sdasd@gmail.com','1','','persona 1','9898956'),
('2','Gustavo','71992784','92563458','','5 de febrero','','','1','','',''),
('3','Carlos Z','78562136','926812599','','paita','','sadasd@gmail.com','1','','',''),
('4','Karina Maribel','4003884','948611285','DISPONIBLE','paita Piura','','karina@gmail.com','1','','',''),
('6','ss','78562136dd','5446','','hfdgh','','gfhfgh','1','','',''),
('7','MArtin','71558899','123456','','fsdf','','','1','','',''),
('8','Juan Carlos Masias Salvador','1234','9999999','DISPONIBLE','sullana','','','1','','',''),
('9','SDSD','654654','5646546456','','KJHJ','','','1','','',''),
('10','Javbie gomez','8976568','7895623','con prestamo','paita hduu','','juangustavo1315@gmail.com','1','','',''),
('11','ejm','78787','95623145','DISPONIBLE','pait','','','1','','',''),
('12','stuart edit','7856926','92586413','con prestamo','la 5','','juangustavo1315@gmail.com','1','','editado','565623');

-- ----------------------------
-- Table structure for empresa
-- ----------------------------
 
DROP TABLE IF EXISTS `empresa`;
CREATE TABLE `empresa` (
  `confi_id` int(11) NOT NULL AUTO_INCREMENT,
  `confi_razon` varchar(255) DEFAULT NULL,
  `confi_ruc` varchar(40) DEFAULT NULL,
  `confi_direccion` varchar(255) DEFAULT NULL,
  `confi_correlativo` varchar(8) DEFAULT NULL,
  `config_correo` varchar(50) DEFAULT NULL,
  `config_celular` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`confi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table empresa
-- ----------------------------
 
INSERT INTO `empresa` (`confi_id`,`confi_razon`,`confi_ruc`,`confi_direccion`,`confi_correlativo`,`config_correo`,`config_celular`) VALUES
('1','Sistema de Prestamos ','1020304050','el nuevo por nevir','00000090','gmasiasdeveloper@gmail.com','922804671');

-- ----------------------------
-- Table structure for forma_pago
-- ----------------------------
 
DROP TABLE IF EXISTS `forma_pago`;
CREATE TABLE `forma_pago` (
  `fpago_id` int(11) NOT NULL AUTO_INCREMENT,
  `fpago_descripcion` varchar(255) DEFAULT NULL,
  `valor` char(10) DEFAULT NULL,
  `aplica_dias` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`fpago_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table forma_pago
-- ----------------------------
 
INSERT INTO `forma_pago` (`fpago_id`,`fpago_descripcion`,`valor`,`aplica_dias`) VALUES
('1','Diario','1','1'),
('2','Semanal','7','1'),
('3','Quincenal','15','1'),
('4','Mensual','1','0'),
('5','Bimestral','2','0'),
('6','Semestrual','6','0'),
('7','Anual','1','0');

-- ----------------------------
-- Table structure for modulos
-- ----------------------------
 
DROP TABLE IF EXISTS `modulos`;
CREATE TABLE `modulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modulo` varchar(255) DEFAULT NULL,
  `padre_id` int(11) DEFAULT NULL,
  `vista` varchar(50) DEFAULT NULL,
  `icon_menu` varchar(50) DEFAULT NULL,
  `orden` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table modulos
-- ----------------------------
 
INSERT INTO `modulos` (`id`,`modulo`,`padre_id`,`vista`,`icon_menu`,`orden`) VALUES
('1','Tablero pincipal','0','dashboard.php','fas fa-tachometer-alt','0'),
('10','Reportes','0','','fas fa-chart-line','15'),
('11','Empresa','0','configuracion.php','fas fa-landmark','9'),
('12','Usuarios','14','usuario.php','far fa-user','13'),
('13','Modulos y Perfiles','14','modulos_perfiles.php','fas fa-tablet-alt','14'),
('14','Mantenimiento','0','','fas fa-cogs','12'),
('24','Clientes','0','cliente.php','fas fa-id-card','4'),
('25','Moneda','0','moneda.php','fas fa-dollar-sign','10'),
('29','Prestamos','0','','fas fa-landmark','5'),
('34','Solicitud/Prestamo','29','prestamo.php','far fa-circle','6'),
('35','Listado Prestamos','29','administrar_prestamos.php','far fa-circle','7'),
('36','Aprobar S/P','29','aprobacion.php','far fa-circle','8'),
('37','Por Cliente','10','reporte_cliente.php','far fa-circle','16'),
('38','Cuotas Pagadas','10','reporte_cuotas_pagadas.php','far fa-circle','17'),
('39','Caja','0','','fas fa-cash-register','1'),
('40','Aperturar Caja','39','caja.php','far fa-circle','2'),
('41','Ingresos / Egre','39','ingresos.php','far fa-circle','3'),
('43','Pivot','10','reportes.php','far fa-circle','18'),
('45','ejm2','0','ejmp.php','far fa-circle','19'),
('46','ejm3','45','sdsd.php','far fa-circle','20'),
('47','Backup','0','index_backup.php','fas fa-database','11');

-- ----------------------------
-- Table structure for moneda
-- ----------------------------
 
DROP TABLE IF EXISTS `moneda`;
CREATE TABLE `moneda` (
  `moneda_id` int(11) NOT NULL AUTO_INCREMENT,
  `moneda_nombre` varchar(10) DEFAULT NULL,
  `moneda_abrevia` varchar(10) DEFAULT NULL,
  `moneda_simbolo` varchar(10) DEFAULT NULL,
  `moneda_Descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`moneda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table moneda
-- ----------------------------
 
INSERT INTO `moneda` (`moneda_id`,`moneda_nombre`,`moneda_abrevia`,`moneda_simbolo`,`moneda_Descripcion`) VALUES
('1','Soles','PEN','S/','Sol Peruano'),
('2','Dolar ame','USD','$','Dolar');

-- ----------------------------
-- Table structure for movimientos
-- ----------------------------
 
DROP TABLE IF EXISTS `movimientos`;
CREATE TABLE `movimientos` (
  `movimientos_id` int(11) NOT NULL AUTO_INCREMENT,
  `movi_tipo` varchar(100) DEFAULT NULL,
  `movi_descripcion` varchar(255) DEFAULT NULL,
  `movi_monto` float DEFAULT NULL,
  `movi_fecha` datetime DEFAULT NULL,
  `movi_caja` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`movimientos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table movimientos
-- ----------------------------
 
INSERT INTO `movimientos` (`movimientos_id`,`movi_tipo`,`movi_descripcion`,`movi_monto`,`movi_fecha`,`movi_caja`) VALUES
('13','EGRESO','Almuerzo','20','2022-12-21 13:04:56','CERRADO'),
('14','INGRESO','pasajes','6','2022-12-21 16:19:13','VIGENTE'),
('15','EGRESO','pasa','2','2022-12-21 16:21:30','VIGENTE');

-- ----------------------------
-- Table structure for perfil_modulo
-- ----------------------------
 
DROP TABLE IF EXISTS `perfil_modulo`;
CREATE TABLE `perfil_modulo` (
  `idperfil_modulo` int(11) NOT NULL AUTO_INCREMENT,
  `id_perfil` int(11) NOT NULL,
  `id_modulo` int(11) NOT NULL,
  `vista_inicio` tinyint(4) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idperfil_modulo`),
  KEY `id_perfil` (`id_perfil`),
  KEY `id_modulo` (`id_modulo`),
  CONSTRAINT `perfil_modulo_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `perfiles` (`id_perfil`),
  CONSTRAINT `perfil_modulo_ibfk_2` FOREIGN KEY (`id_modulo`) REFERENCES `modulos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=430 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table perfil_modulo
-- ----------------------------
 
INSERT INTO `perfil_modulo` (`idperfil_modulo`,`id_perfil`,`id_modulo`,`vista_inicio`,`estado`) VALUES
('174','1','13','0','1'),
('257','3','1','1','1'),
('258','3','24','0','1'),
('259','3','34','0','1'),
('260','3','29','0','1'),
('261','3','35','0','1'),
('262','2','34','1','1'),
('263','2','29','0','1'),
('264','2','35','0','1'),
('412','1','1','1','1'),
('413','1','40','0','1'),
('414','1','39','0','1'),
('415','1','41','0','1'),
('416','1','24','0','1'),
('417','1','34','0','1'),
('418','1','29','0','1'),
('419','1','35','0','1'),
('420','1','36','0','1'),
('421','1','11','0','1'),
('422','1','25','0','1'),
('423','1','12','0','1'),
('424','1','14','0','1'),
('425','1','37','0','1'),
('426','1','10','0','1'),
('427','1','38','0','1'),
('428','1','43','0','1'),
('429','1','47','0','1');

-- ----------------------------
-- Table structure for perfiles
-- ----------------------------
 
DROP TABLE IF EXISTS `perfiles`;
CREATE TABLE `perfiles` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table perfiles
-- ----------------------------
 
INSERT INTO `perfiles` (`id_perfil`,`descripcion`,`estado`) VALUES
('1','Administrador','1'),
('2','Vendedor','1'),
('3','Marketing','1'),
('5','contabilidad','1');

-- ----------------------------
-- Table structure for prestamo_cabecera
-- ----------------------------
 
DROP TABLE IF EXISTS `prestamo_cabecera`;
CREATE TABLE `prestamo_cabecera` (
  `pres_id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_prestamo` varchar(8) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `pres_monto` float DEFAULT NULL,
  `pres_cuotas` char(10) DEFAULT NULL,
  `pres_interes` float DEFAULT NULL,
  `fpago_id` int(11) DEFAULT NULL,
  `moneda_id` int(11) DEFAULT NULL,
  `pres_f_emision` date DEFAULT NULL,
  `pres_monto_cuota` float DEFAULT NULL,
  `pres_monto_interes` float DEFAULT NULL,
  `pres_monto_total` float DEFAULT NULL,
  `pres_estado` varchar(255) DEFAULT NULL,
  `pres_estatus` char(10) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `pres_aprobacion` varchar(20) DEFAULT NULL,
  `pres_cuotas_pagadas` varchar(10) DEFAULT NULL,
  `pres_monto_restante` float DEFAULT NULL,
  `pres_cuotas_restante` varchar(10) DEFAULT NULL,
  `pres_fecha_registro` date DEFAULT NULL,
  `pres_estado_caja` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pres_id`,`nro_prestamo`) USING BTREE,
  KEY `cliente_id` (`cliente_id`),
  KEY `fpago_id` (`fpago_id`),
  KEY `moneda_id` (`moneda_id`),
  CONSTRAINT `prestamo_cabecera_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`),
  CONSTRAINT `prestamo_cabecera_ibfk_2` FOREIGN KEY (`fpago_id`) REFERENCES `forma_pago` (`fpago_id`),
  CONSTRAINT `prestamo_cabecera_ibfk_3` FOREIGN KEY (`moneda_id`) REFERENCES `moneda` (`moneda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table prestamo_cabecera
-- ----------------------------
 
INSERT INTO `prestamo_cabecera` (`pres_id`,`nro_prestamo`,`cliente_id`,`pres_monto`,`pres_cuotas`,`pres_interes`,`fpago_id`,`moneda_id`,`pres_f_emision`,`pres_monto_cuota`,`pres_monto_interes`,`pres_monto_total`,`pres_estado`,`pres_estatus`,`id_usuario`,`pres_aprobacion`,`pres_cuotas_pagadas`,`pres_monto_restante`,`pres_cuotas_restante`,`pres_fecha_registro`,`pres_estado_caja`) VALUES
('50','00000084','12','300','5','18','2','1','2022-12-21','70.8','54','354','Finalizado','1','1','finalizado','5','0','0','2022-12-21','CERRADO'),
('51','00000085','10','600','7','15','2','1','2022-12-21','98.57','90','690','Finalizado','1','1','finalizado','7','0','0','2022-12-21','CERRADO'),
('52','00000086','11','200','5','18','1','1','2022-12-22','47.2','36','236','Finalizado','1','1','finalizado','5','0','0','2022-12-21','CERRADO'),
('53','00000087','12','200','6','25','1','1','2022-12-21','41.67','50','250','Finalizado','1','1','finalizado','6','0','0','2022-12-21','VIGENTE'),
('54','00000088','10','450','4','28','1','1','2022-12-21','144','126','576','Finalizado','1','1','finalizado','4','0','0','2022-12-21','VIGENTE'),
('55','00000089','10','270','4','15','2','1','2022-12-21','77.63','40.5','310.5','Anulado','1','1','anulado','','','','2022-12-21',''),
('56','00000090','12','180','4','15','2','1','2022-12-25','51.75','27','207','Pendiente','1','1','aprobado','1','155','3','2022-12-21','VIGENTE');

-- ----------------------------
-- Table structure for prestamo_detalle
-- ----------------------------
 
DROP TABLE IF EXISTS `prestamo_detalle`;
CREATE TABLE `prestamo_detalle` (
  `pdetalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_prestamo` varchar(8) NOT NULL,
  `pdetalle_nro_cuota` varchar(8) NOT NULL,
  `pdetalle_monto_cuota` float DEFAULT NULL,
  `pdetalle_fecha` datetime DEFAULT NULL,
  `pdetalle_estado_cuota` varchar(100) DEFAULT NULL,
  `pdetalle_fecha_registro` timestamp NULL DEFAULT NULL,
  `pdetalle_saldo_cuota` float DEFAULT NULL,
  `pdetalle_cant_cuota_pagada` varchar(10) DEFAULT NULL,
  `pdetalle_liquidar` varchar(10) DEFAULT NULL,
  `pdetalle_monto_liquidar` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pdetalle_id`),
  KEY `pres_id` (`nro_prestamo`)
) ENGINE=InnoDB AUTO_INCREMENT=286 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table prestamo_detalle
-- ----------------------------
 
INSERT INTO `prestamo_detalle` (`pdetalle_id`,`nro_prestamo`,`pdetalle_nro_cuota`,`pdetalle_monto_cuota`,`pdetalle_fecha`,`pdetalle_estado_cuota`,`pdetalle_fecha_registro`,`pdetalle_saldo_cuota`,`pdetalle_cant_cuota_pagada`,`pdetalle_liquidar`,`pdetalle_monto_liquidar`) VALUES
('251','00000084','1','70.8','2022-12-21 00:00:00','pagada','2022-12-21 13:07:47','283.2','4','0',''),
('252','00000084','2','70.8','2022-12-28 00:00:00','pagada','2022-12-21 13:08:16','212.4','3','0',''),
('253','00000084','3','70.8','2023-01-04 00:00:00','pagada','2022-12-21 13:08:18','141.6','2','0',''),
('254','00000084','4','70.8','2023-01-11 00:00:00','pagada','2022-12-21 13:08:21','70.8','1','0',''),
('255','00000084','5','70.8','2023-01-18 00:00:00','pagada','2022-12-21 13:08:34','0','0','0',''),
('256','00000085','1','98.57','2022-12-21 00:00:00','pagada','2022-12-21 14:12:45','591.43','6','0',''),
('257','00000085','2','98.57','2022-12-28 00:00:00','pagada','2022-12-21 14:13:09','492.86','5','0',''),
('258','00000085','3','98.57','2023-01-04 00:00:00','pagada','2022-12-21 14:13:11','394.29','4','0',''),
('259','00000085','4','98.57','2023-01-11 00:00:00','pagada','2022-12-21 14:13:13','295.72','3','0',''),
('260','00000085','5','98.57','2023-01-18 00:00:00','pagada','2022-12-21 14:13:23','197.15','2','0',''),
('261','00000085','6','98.57','2023-01-25 00:00:00','pagada','2022-12-21 14:13:25','98.58','1','0',''),
('262','00000085','7','98.57','2023-02-01 00:00:00','pagada','2022-12-21 14:13:41','0','0','0',''),
('263','00000086','1','47.2','2022-12-22 00:00:00','pagada','2022-12-21 14:25:46','188.8','4','0',''),
('264','00000086','2','47.2','2022-12-23 00:00:00','pagada','2022-12-21 14:25:48','141.6','3','0',''),
('265','00000086','3','47.2','2022-12-24 00:00:00','pagada','2022-12-21 14:25:50','94.4','2','0',''),
('266','00000086','4','47.2','2022-12-25 00:00:00','pagada','2022-12-21 14:25:52','47.2','1','0',''),
('267','00000086','5','47.2','2022-12-26 00:00:00','pagada','2022-12-21 14:25:54','0','0','0',''),
('268','00000087','1','41.67','2022-12-21 00:00:00','pagada','2022-12-21 15:32:48','208.33','5','0',''),
('269','00000087','2','41.67','2022-12-22 00:00:00','pagada','2022-12-21 15:32:50','166.66','4','0',''),
('270','00000087','3','41.67','2022-12-23 00:00:00','pagada','2022-12-21 15:43:08','124.99','3','0',''),
('271','00000087','4','41.67','2022-12-24 00:00:00','pagada','2022-12-21 15:43:10','83.32','2','0',''),
('272','00000087','5','41.67','2022-12-25 00:00:00','pagada','2022-12-21 15:43:11','41.65','1','0',''),
('273','00000087','6','41.67','2022-12-26 00:00:00','pagada','2022-12-21 15:43:13','0','0','0',''),
('274','00000088','1','144','2022-12-21 00:00:00','pagada','2022-12-21 15:48:37','432','3','0',''),
('275','00000088','2','144','2022-12-22 00:00:00','pagada','2022-12-21 15:48:39','288','2','0',''),
('276','00000088','3','144','2022-12-23 00:00:00','pagada','2022-12-21 15:50:55','144','1','0',''),
('277','00000088','4','144','2022-12-24 00:00:00','pagada','2022-12-21 15:51:02','0','0','0',''),
('278','00000089','1','77.63','2022-12-21 00:00:00','pendiente','','','','0',''),
('279','00000089','2','77.63','2022-12-28 00:00:00','pendiente','','','','0',''),
('280','00000089','3','77.63','2023-01-04 00:00:00','pendiente','','','','0',''),
('281','00000089','4','77.63','2023-01-11 00:00:00','pendiente','','','','0',''),
('282','00000090','1','51.75','2022-12-25 00:00:00','pagada','2022-12-21 16:36:41','155.25','3','0',''),
('283','00000090','2','51.75','2023-01-01 00:00:00','pendiente','','','','0',''),
('284','00000090','3','51.75','2023-01-08 00:00:00','pendiente','','','','0',''),
('285','00000090','4','51.75','2023-01-15 00:00:00','pendiente','','','','0','');

-- ----------------------------
-- Table structure for referencias
-- ----------------------------
 
DROP TABLE IF EXISTS `referencias`;
CREATE TABLE `referencias` (
  `refe_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `refe_personal` varchar(255) DEFAULT NULL,
  `refe_cel_per` varchar(20) DEFAULT NULL,
  `refe_familiar` varchar(255) DEFAULT NULL,
  `refe_cel_fami` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`refe_id`),
  KEY `cliente_id` (`cliente_id`),
  CONSTRAINT `referencias_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`cliente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table referencias
-- ----------------------------
 
INSERT INTO `referencias` (`refe_id`,`cliente_id`,`refe_personal`,`refe_cel_per`,`refe_familiar`,`refe_cel_fami`) VALUES
('6','2','Carlos','8989','maria','23232'),
('7','3','rtrtr','565656','4gfg','rffffff565656'),
('12','9','eeeerrr','3333','',''),
('19','1','joanek','454545','99945233','sullana la nueva'),
('20','6','modificad','78562136dd','5446','hfdgh'),
('21','6','modifi','78562136dd','5446','hfdgh');

-- ----------------------------
-- Table structure for rol
-- ----------------------------
 
DROP TABLE IF EXISTS `rol`;
CREATE TABLE `rol` (
  `rol_id` int(11) NOT NULL,
  `nombre_rol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 
-- ----------------------------
-- Records for table rol
-- ----------------------------
 
INSERT INTO `rol` (`rol_id`,`nombre_rol`) VALUES
('1','Administrador'),
('2','Prestamista');

-- ----------------------------
-- Table structure for usuarios
-- ----------------------------
 
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(100) DEFAULT NULL,
  `apellido_usuario` varchar(100) DEFAULT NULL,
  `usuario` varchar(100) NOT NULL,
  `clave` text NOT NULL,
  `id_perfil_usuario` int(11) DEFAULT NULL,
  `estado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `id_perfil_usuario` (`id_perfil_usuario`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_perfil_usuario`) REFERENCES `perfiles` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
 
-- ----------------------------
-- Records for table usuarios
-- ----------------------------
 
INSERT INTO `usuarios` (`id_usuario`,`nombre_usuario`,`apellido_usuario`,`usuario`,`clave`,`id_perfil_usuario`,`estado`) VALUES
('1','Gustavo ','Masias','gmasias','$2a$07$azybxcags23425sdg23sdeWdBD5K/WLuiEyQ3M9yIJwhDvhbblzKK','1','1'),
('2','Tutoriales','PHPeru','tperu','$2a$07$azybxcags23425sdg23sdeanQZqjaf6Birm2NvcYTNtJw24CsO5uq','1','1'),
('3','Paolo','Guerrero','pguerrero','$2a$07$azybxcags23425sdg23sdeQV6FpIgMbxN5/UQczrrYzgUFea.ig9K','2','1'),
('8','Administrador','Admini','admin','$2a$07$azybxcags23425sdg23sdeWdBD5K/WLuiEyQ3M9yIJwhDvhbblzKK','3','1');
/*{
-- ============================================== PROCEDURES ================================================
-- ----------------------------
-- Procedure structure for SP_ACTUALIZAR_ESTADO_CLIENTE_PRESTAMO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ACTUALIZAR_ESTADO_CLIENTE_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ACTUALIZAR_ESTADO_CLIENTE_PRESTAMO`(IN ID INT)
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM prestamo_cabecera where cliente_id =  ID );

UPDATE clientes SET 
cliente_estado_prestamo = 'con prestamo' 
-- cliente_cant_prestamo = @CANTIDAD + 1
WHERE
	cliente_id = ID;
	
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ALERTA_PRESTAMO_CAJA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ALERTA_PRESTAMO_CAJA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ALERTA_PRESTAMO_CAJA`()
SELECT 

(select  ROUND(SUM(pres_monto),2) from prestamo_cabecera where pres_aprobacion in ('aprobado','pendiente') and pres_estado_caja = 'VIGENTE') as pres_monto,

(select caja_monto_inicial from caja WHERE caja_estado = 'VIGENTE')  AS monto_inicial_caja,
 
(select IFNULL(ROUND(SUM(movi_monto),2),0) from movimientos WHERE movi_tipo = 'INGRESO' AND  movi_caja = 'VIGENTE') as ingreso,


(select IFNULL(ROUND(SUM(movi_monto),2),0) from movimientos WHERE movi_tipo = 'EGRESO' AND  movi_caja = 'VIGENTE') as egreso,

(select  IFNULL(ROUND(SUM(pres_monto_interes),2),0) from prestamo_cabecera where pres_aprobacion in ('finalizado') and pres_estado_caja = 'VIGENTE') as interes ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_CAMBIAR_ESTADO_CABECERA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_CAMBIAR_ESTADO_CABECERA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CAMBIAR_ESTADO_CABECERA`(IN prestamo VARCHAR(8))
BEGIN
DECLARE ESTADO INT;
DECLARE CLIENTE INT;
SET @ESTADO:=(select count(*) from prestamo_detalle pd where pd.nro_prestamo = prestamo and pd.pdetalle_estado_cuota like '%pendiente%' );
SET @CLIENTE:=(select cliente_id from prestamo_cabecera where nro_prestamo = prestamo);

 IF  @ESTADO = 0 THEN 
        UPDATE prestamo_cabecera SET
	pres_aprobacion = 'finalizado',
	pres_estado = 'Finalizado'
	WHERE nro_prestamo = prestamo;
	
	UPDATE clientes SET
	cliente_estado_prestamo = 'DISPONIBLE'
	WHERE cliente_id = @CLIENTE;
	

	
	
SELECT 'ok';
ELSE
	SELECT 'error';
END IF;


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_CLIENTES_CON_PRESTAMOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_CLIENTES_CON_PRESTAMOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CLIENTES_CON_PRESTAMOS`()
BEGIN
SELECT
	-- pc.cliente_id,
	c.cliente_dni,
	c.cliente_nombres,
	count( pc.nro_prestamo ) AS cant,
	SUM( pc.pres_monto_total ) AS total 
FROM
	prestamo_cabecera pc
	INNER JOIN clientes c ON pc.cliente_id = c.cliente_id 
WHERE
	pc.pres_aprobacion IN ( 'aprobado', 'finalizado' ) 
GROUP BY
	pc.cliente_id 
ORDER BY
	SUM(
		ROUND( pc.pres_monto_total, 2 )) DESC 
		LIMIT 10;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_CUOTAS_PAGADAS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_CUOTAS_PAGADAS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CUOTAS_PAGADAS`(in prestamo VARCHAR(8))
select IFNULL(count(pdetalle_estado_cuota),0) as pdetalle_estado_cuota ,
			(select 	IFNULL(count(pdetalle_estado_cuota),0) from prestamo_detalle where nro_prestamo = prestamo AND  pdetalle_estado_cuota = 'pendiente') as pendiente
			from prestamo_detalle 
where nro_prestamo = prestamo AND 
			pdetalle_estado_cuota = 'pagada' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_CUOTAS_VENCIDAS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_CUOTAS_VENCIDAS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_CUOTAS_VENCIDAS`()
BEGIN
	SELECT
		pc.cliente_id,
		c.cliente_dni,
		c.cliente_nombres,
		pd.nro_prestamo,
		pd.pdetalle_nro_cuota,
		DATE_FORMAT(pd.pdetalle_fecha,'%d/%m/%Y') as fecha,
		pd.pdetalle_monto_cuota,
		pc.id_usuario,
		u.nombre_usuario,
		CURDATE(),
		DATE(pd.pdetalle_fecha),
		(CURDATE() - DATE(pd.pdetalle_fecha) ) as resta
		
	FROM
		prestamo_cabecera pc
		INNER JOIN clientes c ON pc.cliente_id = c.cliente_id
		INNER JOIN prestamo_detalle pd ON pc.nro_prestamo = pd.nro_prestamo 
		INNER JOIN usuarios u on pc.id_usuario =  u.id_usuario
	WHERE
		CURDATE() >= DATE(pd.pdetalle_fecha) and
		
		pc.pres_aprobacion = 'aprobado' 
		and pd.pdetalle_estado_cuota = 'pendiente'
		ORDER BY 	DATE(pd.pdetalle_fecha) ASC;
	-- 	LIMIT 10;
		

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_DATOS_DASHBOARD
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_DATOS_DASHBOARD`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_DATOS_DASHBOARD`()
BEGIN
	DECLARE
		CAJA FLOAT;
	DECLARE
		CLIENTES FLOAT;
	DECLARE
		PRESTAMOSPEN FLOAT;
	DECLARE
		TOTALACOBRAR FLOAT;
		
	DECLARE PRODUCTOSINSTOCK INT;
	DECLARE INTERES INT;
	DECLARE TOTALPRES INT;
		
		SET CAJA = (select cj.caja_monto_total  from caja cj where cj.caja_estado = 'vigente');
		SET CLIENTES = (select COUNT(*) from clientes c WHERE c.cliente_estatus ='1');
		SET PRESTAMOSPEN =(select COUNT(*)  from prestamo_cabecera pc where pc.pres_aprobacion in ('aprobado', 'pendiente'));
		-- SET TOTALACOBRAR = (select SUM(pd.pdetalle_monto_cuota) from prestamo_detalle pd where pd.pdetalle_estado_cuota = 'pendiente'  );
		SET TOTALACOBRAR = (select SUM(pc.pres_monto_total) from prestamo_cabecera pc where pc.pres_aprobacion in ('aprobado', 'pendiente') );
		SET INTERES = (select  IFNULL(ROUND(SUM(pres_monto_interes),2),0) from prestamo_cabecera where pres_aprobacion in ('finalizado') and pres_estado_caja = 'VIGENTE');
		SET TOTALPRES = (select caja_monto_inicial from caja WHERE caja_estado = 'VIGENTE');
		
	-- 	SET VENTASDELDIA = (select SUM(vc.total_venta) from venta_cabecera vc where vc.fecha_venta = CURDATE());
		
		
	SELECT
	  IFNULL(ROUND(CAJA,2),0)	as caja ,
		IFNULL(CLIENTES,0) as clientes,
		IFNULL(PRESTAMOSPEN,0) as prestamospen,
	  IFNULL(ROUND(TOTALACOBRAR,2), 0) as totalacobrar;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_DESAPROBAR_PRESTAMO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_DESAPROBAR_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_DESAPROBAR_PRESTAMO`(IN N_PRESTAMO VARCHAR(8))
BEGIN 

DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM prestamo_detalle where pdetalle_estado_cuota ='pagada' AND nro_prestamo = N_PRESTAMO);
if @CANTIDAD = 0 THEN
	
		UPDATE prestamo_cabecera SET 
		pres_aprobacion = 'pendiente' ,
		pres_estado_caja = 'VIGENTE',
		pres_estado = 'Pendiente' 
		where nro_prestamo = N_PRESTAMO;
		
		/*UPDATE prestamo_cabecera SET 
		pres_estado_caja = "" 
		where nro_prestamo = N_PRESTAMO;*/
		
SELECT 1;
ELSE
SELECT 2;
END IF;


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_EDITAR_MOVIMIENTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_EDITAR_MOVIMIENTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_EDITAR_MOVIMIENTO`(IN ID VARCHAR(11), IN TIPO_MOV VARCHAR(100), IN DESCRIPCION VARCHAR(100), IN MONTO FLOAT)
BEGIN 

DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM movimientos where movi_caja ='CERRADO' AND movimientos_id = ID);
if @CANTIDAD = 0 THEN
		
		UPDATE movimientos SET
		movi_tipo = TIPO_MOV,
		movi_descripcion = DESCRIPCION,
		movi_monto = MONTO
		where movimientos_id = ID;
		
SELECT 1;
ELSE
SELECT 2;
END IF;


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ELIMINAR_MOVIMIENTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ELIMINAR_MOVIMIENTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ELIMINAR_MOVIMIENTO`(IN ID VARCHAR(11))
BEGIN 

DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM movimientos where movi_caja ='CERRADO' AND movimientos_id = ID);
if @CANTIDAD = 0 THEN
	
		DELETE FROM movimientos  
		where movimientos_id = ID;
		
SELECT 1;
ELSE
SELECT 2;
END IF;


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LIQUIDAR_PRESTAMO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LIQUIDAR_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LIQUIDAR_PRESTAMO`(IN prestamo VARCHAR(8), IN cuota VARCHAR(8))
BEGIN

DECLARE MONTOTOTAL INT;
DECLARE MONTOCUOTA INT;
DECLARE CANTCUOTADETA INT;
DECLARE CANTCUOCABE INT;
DECLARE MONTORESTANTECABE INT;
DECLARE MAXINROCUOTA INT;
DECLARE CLIENTE INT;

SET @MONTOTOTAL:=(select pres_monto_total from prestamo_cabecera where nro_prestamo = prestamo);   -- 768
-- SET @MONTOCUOTA:=(select ROUND(SUM(pdetalle_monto_cuota),2) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_estado_cuota = 'pagada' ); -- 172.5
 SET @MONTORESTANTECABE:=(select pres_monto_restante from prestamo_cabecera where nro_prestamo = prestamo  ); 
SET @MAXINROCUOTA:=(select max(pdetalle_monto_cuota) from prestamo_detalle where nro_prestamo = prestamo  );
SET @MONTOCUOTA:=(select ROUND(SUM(pdetalle_monto_cuota),2) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_monto_liquidar = '1' );

--  SET @CANTCUOTADETA:=(select count(pdetalle_estado_cuota) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_estado_cuota = 'pagada');
 SET @CANTCUOTADETA:=(select count(pdetalle_liquidar) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_liquidar = '1');
SET @CANTCUOCABE:=(select pres_cuotas from prestamo_cabecera where nro_prestamo = prestamo);

SET @CLIENTE:=(select cliente_id from prestamo_cabecera where nro_prestamo = prestamo);

UPDATE prestamo_detalle SET 
pdetalle_liquidar = '1',
pdetalle_monto_liquidar = '1',
 pdetalle_saldo_cuota = @MONTORESTANTECABE,
pdetalle_cant_cuota_pagada = (@CANTCUOCABE - @CANTCUOTADETA) -1
where nro_prestamo = prestamo 
and pdetalle_nro_cuota = cuota;
-- and pdetalle_estado_cuota = 'pendiente';

UPDATE clientes SET
cliente_estado_prestamo = 'DISPONIBLE'
WHERE cliente_id = @CLIENTE;




END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CAJA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CAJA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CAJA`()
SELECT
	caja_id,
	-- caja_descripcion,
	caja_monto_inicial,
	IFNULL(caja_monto_ingreso,0),
	caja__monto_egreso,
	caja_prestamo,
 CONCAT_WS(' ',DATE_FORMAT(caja_f_apertura, '%d/%m/%Y'), caja_hora_apertura) as f_apert,
  CONCAT_WS(' ',DATE_FORMAT(caja_f_cierre, '%d/%m/%Y'), caja_hora_cierre) as caja_f_cierre,
 -- caja_f_cierre,
-- 	(select count(*) from prestamo_cabecera where pres_aprobacion = 'Aprobado' and pres_fecha_registro = CURDATE()) as cant_pres,
caja_count_prestamo,
	caja_monto_total,
	caja_estado,
	'' as opciones
FROM
	caja ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CLIENTES_PRESTAMO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CLIENTES_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CLIENTES_PRESTAMO`()
SELECT
	cliente_id, 
	cliente_nombres, 
	cliente_dni, 
	cliente_estado_prestamo, 
	cliente_estatus

FROM
	clientes ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CLIENTES_TABLE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CLIENTES_TABLE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CLIENTES_TABLE`()
SELECT
	cliente_id, 
	cliente_nombres, 
	cliente_dni, 
	cliente_cel, 
	cliente_estado_prestamo, 
	cliente_estatus,
	cliente_direccion,
	cliente_correo,
	'' as opciones,
	cliente_refe,
	cliente_cel_refe
FROM
	clientes ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_MONEDAS_TABLE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_MONEDAS_TABLE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_MONEDAS_TABLE`()
SELECT
	moneda_id, 
	moneda_nombre, 
	moneda_abrevia, 
	moneda_simbolo, 
	moneda_Descripcion,
	'' as opciones
FROM
	moneda ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_MOVIMIENTOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_MOVIMIENTOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_MOVIMIENTOS`()
SELECT
	movimientos_id,
	movi_tipo,
	movi_descripcion,
	ROUND(movi_monto,2) as monto,
	 DATE_FORMAT(movi_fecha, '%d/%m/%Y') as fecha,
	 movi_caja,
	'' as opciones
	
FROM
	movimientos ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_PRESTAMOS_POR_APROBACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_PRESTAMOS_POR_APROBACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_PRESTAMOS_POR_APROBACION`( in fecha_ini DATE, in fecha_fin DATE)
select pc.pres_id ,
				pc.nro_prestamo,
				pc.cliente_id,
				c.cliente_nombres,
				pc.pres_monto,
			  pc.pres_interes,
			  pc.pres_cuotas,
				pc.fpago_id,
				fp.fpago_descripcion,
				pc.id_usuario,
				u.usuario,		
				DATE(pc.pres_fecha_registro) as fecha,
				pc.pres_aprobacion as estado,
				'' as opciones
							
				 from prestamo_cabecera pc
				 INNER JOIN clientes c on
				 pc.cliente_id = c.cliente_id
				 INNER JOIN forma_pago fp on 
				 pc.fpago_id = fp.fpago_id
				 INNER JOIN usuarios u on
				 pc.id_usuario = u.id_usuario
				 WHERE pc.pres_fecha_registro BETWEEN fecha_ini AND fecha_fin ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_REFERENCIAS_EN_CLIENTE_EDIT
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_REFERENCIAS_EN_CLIENTE_EDIT`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_REFERENCIAS_EN_CLIENTE_EDIT`(IN ID INT)
SELECT
cliente_id,
refe_personal,
refe_cel_per,
refe_familiar,
refe_cel_fami
	
FROM
	referencias
	where cliente_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ANIO_RECORD
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ANIO_RECORD`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ANIO_RECORD`()
SELECT YEAR(pres_fecha_registro) as anio FROM prestamo_cabecera
where pres_aprobacion IN  ('aprobado', 'finalizado' )
GROUP BY YEAR(pres_fecha_registro) ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_USUARIO_RECORD
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_USUARIO_RECORD`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_USUARIO_RECORD`()
SELECT u.id_usuario,
	CONCAT_WS( ' | ', u.usuario, u.nombre_usuario ) AS usu 
FROM
	prestamo_cabecera pc
	INNER JOIN usuarios u ON pc.id_usuario = u.id_usuario 
WHERE
	pres_aprobacion IN ( 'aprobado', 'finalizado' ) 
GROUP BY
	u.id_usuario ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_USUARIOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_USUARIOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_USUARIOS`()
SELECT
	usuarios.id_usuario,
	usuarios.nombre_usuario,
	usuarios.apellido_usuario,
	-- CONCAT_WS(' ', usuarios.nombre_usuario,usuarios.apellido_usuario) as nombre, 
	usuarios.usuario, 
	usuarios.clave,
	usuarios.id_perfil_usuario, 
	perfiles.descripcion, 
	usuarios.estado,
	'' as opciones
FROM
	usuarios
	INNER JOIN
	perfiles
	ON 
		usuarios.id_perfil_usuario = perfiles.id_perfil
		
		ORDER BY usuarios.id_usuario ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MONTO_POR_CUOTA_PAGADA_D
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MONTO_POR_CUOTA_PAGADA_D`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MONTO_POR_CUOTA_PAGADA_D`(IN prestamo VARCHAR(8), IN cuota VARCHAR(8))
BEGIN

DECLARE MONTOTOTAL INT;
DECLARE MONTOCUOTA INT;
DECLARE CANTCUOTADETA INT;
DECLARE CANTCUOCABE INT;

SET @MONTOTOTAL:=(select pres_monto_total from prestamo_cabecera where nro_prestamo = prestamo);
SET @MONTOCUOTA:=(select SUM(pdetalle_monto_cuota) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_estado_cuota = 'pagada' );

SET @CANTCUOTADETA:=(select count(pdetalle_estado_cuota) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_estado_cuota = 'pagada');
SET @CANTCUOCABE:=(select pres_cuotas from prestamo_cabecera where nro_prestamo = prestamo);

UPDATE prestamo_detalle SET 
pdetalle_saldo_cuota = @MONTOTOTAL -  @MONTOCUOTA,
pdetalle_cant_cuota_pagada = @CANTCUOCABE - @CANTCUOTADETA
where nro_prestamo = prestamo 
and pdetalle_nro_cuota = cuota;

	UPDATE prestamo_detalle SET
	pdetalle_saldo_cuota = '0'
	where nro_prestamo = prestamo and pdetalle_cant_cuota_pagada = '0' ;



END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_OBTENER_DATA_CLIENTE_TEX
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_OBTENER_DATA_CLIENTE_TEX`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_OBTENER_DATA_CLIENTE_TEX`(in cliente_dni VARCHAR(20))
SELECT
c.cliente_id,
c.cliente_nombres,
cliente_dni
FROM
	clientes c
	where c.cliente_dni = cliente_dni ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_OBTENER_DATA_EMPRESA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_OBTENER_DATA_EMPRESA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_OBTENER_DATA_EMPRESA`()
SELECT
	empresa.confi_id, 
	empresa.confi_razon, 
	empresa.confi_ruc, 
	empresa.confi_direccion, 
	empresa.confi_correlativo, 
	empresa.config_correo
FROM
	empresa ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_OBTENER_ESTADO_CAJA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_OBTENER_ESTADO_CAJA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_OBTENER_ESTADO_CAJA`()
SELECT
	caja_estado,
	caja_f_apertura,
	caja_hora_apertura,
	caja_monto_total,
	caja_monto_ingreso 
FROM
	caja 
WHERE
	caja_estado = 'VIGENTE' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_OBTENER_NRO_CORRELATIVO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_OBTENER_NRO_CORRELATIVO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_OBTENER_NRO_CORRELATIVO`()
SELECT 
	
		IFNULL(LPAD(MAX(c.confi_correlativo)+1,8,'0'),'00000001') nro_prestamo
		
		from empresa c ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_PRESTAMOS_MES_ACTUAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_PRESTAMOS_MES_ACTUAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_PRESTAMOS_MES_ACTUAL`()
BEGIN
	SELECT
		DATE_FORMAT(pc.pres_fecha_registro,'%d/%m/%Y') as fecha,
		SUM(ROUND(pc.pres_monto_total,2)) as totalprestamo
	FROM
		prestamo_cabecera pc
	WHERE
			DATE(pc.pres_fecha_registro) >= DATE( LAST_DAY( NOW() - INTERVAL 1 MONTH ) + INTERVAL 1 DAY ) 
		AND 	DATE(pc.pres_fecha_registro) <= LAST_DAY(DATE( CURRENT_DATE )) 
		and  pc.pres_aprobacion in ('aprobado', 'pendiente', 'finalizado')
		GROUP BY 	DATE(pc.pres_fecha_registro) ;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_APERTURA_CAJA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_APERTURA_CAJA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_APERTURA_CAJA`(IN DESCRIPCION VARCHAR(100), IN MONTO_INI FLOAT)
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM caja where caja_estado='VIGENTE');
if @CANTIDAD = 0 THEN
	INSERT INTO caja (caja_descripcion, caja_monto_inicial, caja_f_apertura, caja_estado, caja_hora_apertura) VALUES(DESCRIPCION, MONTO_INI, CURDATE(), 'VIGENTE', CURRENT_TIME());
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_CAJA_CIERRE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_CAJA_CIERRE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_CAJA_CIERRE`(IN MONTO_INGRESO FLOAT, IN MONTO_PRES FLOAT, IN MONTO_EGRES FLOAT, IN MONTO_TOTAL FLOAT,   IN CANT_PRESTA VARCHAR(100), IN CANT_INGRES VARCHAR(100), IN CANT_EGRESO VARCHAR(100), IN INTERES FLOAT)
BEGIN 

DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM prestamo_cabecera where pres_estado_caja ='VIGENTE' AND pres_aprobacion = 'aprobado');
if @CANTIDAD = 0 THEN
	
		UPDATE caja SET 
		caja_monto_ingreso = MONTO_INGRESO,
		caja_prestamo =  MONTO_PRES,
		caja_f_cierre = CURDATE(),
		caja__monto_egreso = MONTO_EGRES,
		caja_monto_total = MONTO_TOTAL,
		caja_estado = 'CERRADO',
		caja_hora_cierre = CURRENT_TIME(),
		caja_count_prestamo = CANT_PRESTA,
		caja_count_ingreso = CANT_INGRES,
		caja_count_egreso = CANT_EGRESO,
		caja_interes = INTERES
		WHERE caja_estado = 'VIGENTE';
		
SELECT 1;
ELSE
SELECT 2;
END IF;





END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_REFERENCIAS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_REFERENCIAS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_REFERENCIAS`(IN ID_CLI INT, IN REFE_PER VARCHAR(255), IN CEL_PER VARCHAR(20), IN REFE_FAM VARCHAR(255), IN CEL_FAM VARCHAR(20))
BEGIN
INSERT INTO referencias (cliente_id, refe_personal, refe_cel_per, refe_familiar, refe_cel_fami) values(ID_CLI, REFE_PER, CEL_PER, REFE_FAM, CEL_FAM);

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_LISTAR_CUOTAS_PAGADAS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_LISTAR_CUOTAS_PAGADAS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_LISTAR_CUOTAS_PAGADAS`()
SELECT
	pc.cliente_id,
	c.cliente_nombres,
	pd.nro_prestamo ,
	pd.pdetalle_nro_cuota,
	pd.pdetalle_monto_cuota,
	pd.pdetalle_fecha_registro,
	pc.moneda_id,
	m.moneda_nombre,
	'' as opciones
	 
FROM
 prestamo_detalle pd

	INNER JOIN 	prestamo_cabecera pc ON 
	pd.nro_prestamo = pc.nro_prestamo
	INNER JOIN clientes c
	on pc.cliente_id = c.cliente_id
	INNER JOIN moneda m 
	on pc.moneda_id = m.moneda_id
WHERE
 pd.pdetalle_estado_cuota = 'pagada' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_LISTAR_TOTAL_CIERRE_CAJA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_LISTAR_TOTAL_CIERRE_CAJA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_LISTAR_TOTAL_CIERRE_CAJA`()
SELECT 
	(select ROUND(MAX(caja_monto_inicial),2) from caja where caja_estado = 'VIGENTE') as monto_inicial_caja,

	-- (select COUNT(pres_monto) from prestamo_cabecera where pres_estado_caja = 'VIGENTE' AND pres_aprobacion in ( 'aprobado' , 'finalizado')) as cant_prestamo,
	(select COUNT(pres_monto) from prestamo_cabecera where pres_estado_caja = 'VIGENTE' AND pres_aprobacion in ( 'finalizado')) as cant_prestamo,
	(select ROUND(IFNULL(SUM(pres_monto),0),2) from prestamo_cabecera where pres_estado_caja = 'VIGENTE' AND pres_aprobacion in (  'finalizado') ) as suma_prestamo_capital,
	(select ROUND(IFNULL(SUM(pres_monto_interes),0),2) from prestamo_cabecera where pres_estado_caja = 'VIGENTE' AND pres_aprobacion in (  'finalizado') ) as suma_prestamo_interes,
	(Select COUNT(*) from movimientos where movi_tipo = 'INGRESO' AND movi_caja = 'VIGENTE') as cant_ingresos,
	(select ROUND(IFNULL(SUM(movi_monto),0),2) from movimientos where movi_tipo = 'INGRESO' AND movi_caja = 'VIGENTE') as suma_ingresos,
	(Select COUNT(*) from movimientos where movi_tipo = 'EGRESO' AND movi_caja = 'VIGENTE') as cant_egresos,
	(select ROUND(IFNULL(SUM(movi_monto),0),2) from movimientos where movi_tipo = 'EGRESO' AND movi_caja = 'VIGENTE') as suma_egresos,
	
	(select caja_estado from caja where caja_estado = 'VIGENTE' ) as estado,
	(select  CONCAT_WS(' ',DATE_FORMAT(caja_f_apertura, '%d/%m/%Y'), caja_hora_apertura)  from caja where caja_estado = 'VIGENTE' ) as fecha_apertura,
	
	(select ROUND(IFNULL(SUM(pres_monto_total),0),2) from prestamo_cabecera where pres_estado_caja = 'VIGENTE' AND pres_aprobacion in (  'finalizado') ) as suma_total ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_PIVOT
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_PIVOT`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_PIVOT`()
SELECT YEAR(pres_f_emision) as anio,
SUM(CASE WHEN MONTH(pres_f_emision)=1 THEN pres_monto_total ELSE 0 END) AS enero,
SUM(CASE WHEN MONTH(pres_f_emision)=2 THEN pres_monto_total ELSE 0 END) AS febrero,
SUM(CASE WHEN MONTH(pres_f_emision)=3 THEN pres_monto_total ELSE 0 END) AS marzo,
SUM(CASE WHEN MONTH(pres_f_emision)=4 THEN pres_monto_total ELSE 0 END) AS abril,
SUM(CASE WHEN MONTH(pres_f_emision)=5 THEN pres_monto_total ELSE 0 END) AS mayo,
SUM(CASE WHEN MONTH(pres_f_emision)=6 THEN pres_monto_total ELSE 0 END) AS junio,
SUM(CASE WHEN MONTH(pres_f_emision)=7 THEN pres_monto_total ELSE 0 END) AS julio,
SUM(CASE WHEN MONTH(pres_f_emision)=8 THEN pres_monto_total ELSE 0 END) AS agosto,
SUM(CASE WHEN MONTH(pres_f_emision)=9 THEN pres_monto_total ELSE 0 END) AS setiembre,
SUM(CASE WHEN MONTH(pres_f_emision)=10 THEN pres_monto_total ELSE 0 END) AS octubre,
SUM(CASE WHEN MONTH(pres_f_emision)=11 THEN pres_monto_total ELSE 0 END) AS noviembre,
SUM(CASE WHEN MONTH(pres_f_emision)=12 THEN pres_monto_total ELSE 0 END) AS diciembre,
SUM(pres_monto_total) as total
FROM prestamo_cabecera
WHERE pres_aprobacion ='finalizado'
GROUP BY YEAR(pres_f_emision) ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_POR_CLIENTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_POR_CLIENTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_POR_CLIENTE`(in id  int)
select pc.pres_id ,
				pc.nro_prestamo,
				pc.cliente_id,
				c.cliente_nombres,
				pc.pres_monto,
				DATE_FORMAT(pc.pres_fecha_registro, '%d/%m/%Y') as fecha,
				pc.pres_monto_total,
				pc.pres_monto_cuota,
			  pc.pres_cuotas,
				pc.fpago_id,
				fp.fpago_descripcion,
				-- pc.id_usuario,
		  	-- 	u.usuario,						
				pc.pres_aprobacion as estado,
				'' as opciones	,
				pc.pres_interes	,
				pc.pres_monto_interes,
				pc.pres_cuotas_pagadas,
				DATE_FORMAT(pc.pres_f_emision, '%d/%m/%Y') as femision
				 from prestamo_cabecera pc
				 INNER JOIN clientes c on
				 pc.cliente_id = c.cliente_id
				 INNER JOIN forma_pago fp on 
				 pc.fpago_id = fp.fpago_id
				 INNER JOIN usuarios u on
				 pc.id_usuario = u.id_usuario
				 WHERE pc.cliente_id = id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_PRESTAMOS_POR_ANIO_AND_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_PRESTAMOS_POR_ANIO_AND_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_PRESTAMOS_POR_ANIO_AND_USUARIO`( IN ID INT,IN ANIO VARCHAR(10))
SELECT 
YEAR(pc.pres_fecha_registro) as anio, 
case month(pc.pres_fecha_registro) 
WHEN 1 THEN 'Enero'
WHEN 2 THEN  'Febrero'
WHEN 3 THEN 'Marzo' 
WHEN 4 THEN 'Abril' 
WHEN 5 THEN 'Mayo'
WHEN 6 THEN 'Junio'
WHEN 7 THEN 'Julio'
WHEN 8 THEN 'Agosto'
WHEN 9 THEN 'Septiembre'
WHEN 10 THEN 'Octubre'
WHEN 11 THEN 'Noviembre'
WHEN 12 THEN 'Diciembre'
 END mesnombre ,
 u.usuario as usu_nombre,
 count(pc.pres_monto_total) as cant_prestamos,
 SUM(pc.pres_monto_total) as total,
MONTH(pc.pres_fecha_registro) as numero_mes, 
MONTHname(pc.pres_fecha_registro) as mes,
pc.id_usuario, 
u.usuario as usu_nombre

FROM prestamo_cabecera pc
INNER JOIN
	usuarios u
	ON 
		pc.id_usuario = u.id_usuario
where pc.pres_aprobacion ='finalizado' and YEAR(pc.pres_fecha_registro) =ANIO and pc.id_usuario = ID
GROUP BY YEAR(pc.pres_fecha_registro),
month(pc.pres_fecha_registro) ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_VER_DETALLE_PRESTAMO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_VER_DETALLE_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_VER_DETALLE_PRESTAMO`(IN nro_prestamo VARCHAR(8))
select pd.pdetalle_id,
pd.nro_prestamo,
				pd.pdetalle_nro_cuota as cuota,
				-- DATE(pd.pdetalle_fecha) as fecha,
				DATE_FORMAT(pd.pdetalle_fecha, '%d/%m/%Y') as fecha,
				pd.pdetalle_monto_cuota as monto,
				pd.pdetalle_estado_cuota as estado,
				'' as accion
				from prestamo_detalle pd
				where pd.nro_prestamo = nro_prestamo ;; 
DELIMITER ; 

-- ============================================== TRIGGERS ================================================
-- ----------------------------
-- Trigger structure for TG_CERRAR_PRESTAMO
-- ----------------------------
 
DROP TRIGGER IF EXISTS `TG_CERRAR_PRESTAMO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `TG_CERRAR_PRESTAMO` BEFORE UPDATE ON `caja` FOR EACH ROW BEGIN

UPDATE prestamo_cabecera SET
pres_estado_caja= 'CERRADO'
where pres_estado_caja='VIGENTE';
END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for TG_CERRAR_MOVI_INGRESO
-- ----------------------------
 
DROP TRIGGER IF EXISTS `TG_CERRAR_MOVI_INGRESO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `TG_CERRAR_MOVI_INGRESO` BEFORE UPDATE ON `caja` FOR EACH ROW BEGIN

UPDATE movimientos SET
movi_caja= 'CERRADO'
where movi_caja='VIGENTE';
END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for tg_montocuota_detalle
-- ----------------------------
 
DROP TRIGGER IF EXISTS `tg_montocuota_detalle`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `tg_montocuota_detalle` AFTER UPDATE ON `prestamo_detalle` FOR EACH ROW BEGIN

/*DECLARE MONTOTOTAL INT;
DECLARE MONTOCUOTA INT;

SET MONTOTOTAL:=(select pres_monto_total from prestamo_cabecera where nro_prestamo = prestamo);
SET MONTOCUOTA:=(select SUM(pdetalle_monto_cuota) from prestamo_detalle where nro_prestamo = prestamo AND pdetalle_estado_cuota = 'pagada' );


	UPDATE prestamo_detalle SET 
	 pdetalle_saldo_cuota = @MONTOTOTAL -  @MONTOCUOTA
	where nro_prestamo = new.nro_prestamo
  and pdetalle_nro_cuota = new.pdetalle_monto_cuota;*/


END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for tg_can_cuotas_cabecera
-- ----------------------------
 
DROP TRIGGER IF EXISTS `tg_can_cuotas_cabecera`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `tg_can_cuotas_cabecera` AFTER UPDATE ON `prestamo_detalle` FOR EACH ROW BEGIN
DECLARE CUOTA INT;
SET CUOTA:=(select count(*) from prestamo_detalle where nro_prestamo = new.nro_prestamo and pdetalle_estado_cuota = 'pagada' );

        UPDATE prestamo_cabecera SET
	pres_cuotas_pagadas = CUOTA
	WHERE nro_prestamo = new.nro_prestamo;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for tg_monto_restante
-- ----------------------------
 
DROP TRIGGER IF EXISTS `tg_monto_restante`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `tg_monto_restante` AFTER UPDATE ON `prestamo_detalle` FOR EACH ROW BEGIN
DECLARE MONTO INT;
SET MONTO:=(select SUM(pdetalle_monto_cuota) from prestamo_detalle where nro_prestamo = new.nro_prestamo AND pdetalle_estado_cuota = 'pagada' );


  UPDATE prestamo_cabecera SET
	pres_monto_restante = pres_monto_total - MONTO
	WHERE nro_prestamo = new.nro_prestamo;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for tg_cuotas_restante
-- ----------------------------
 
DROP TRIGGER IF EXISTS `tg_cuotas_restante`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `tg_cuotas_restante` AFTER UPDATE ON `prestamo_detalle` FOR EACH ROW BEGIN
DECLARE CANTCUOTA INT;
SET CANTCUOTA:=(select count(pdetalle_estado_cuota) from prestamo_detalle where nro_prestamo = new.nro_prestamo AND pdetalle_estado_cuota = 'pagada');


  UPDATE prestamo_cabecera SET
	pres_cuotas_restante = pres_cuotas - CANTCUOTA
	WHERE nro_prestamo = new.nro_prestamo;

END ;; 
DELIMITER ; 
}*/
-- ================================== END DATABASE dbprestamo ========================================

 
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
