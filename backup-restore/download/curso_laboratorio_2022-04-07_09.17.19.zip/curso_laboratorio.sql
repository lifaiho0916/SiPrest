/*{------------------------------------------------------------------------
|  MySQL Database Backup DumpDB
|
|  Host: localhost    Database: curso_laboratorio    CreateAt: 2022-04-07 09:17:19
|
|  Server: version 10.4.22-MariaDB
|
|  Author of DumpDB: < gil_yeung@outlook.com > Gilberto Villarreal Rodriguez 
*-------------------------------------------------------------------------}*/
 

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;


-- ================================== BEGIN DATABASE curso_laboratorio =======================================
-- DROP DATABASE IF EXISTS `curso_laboratorio`;
-- CREATE DATABASE `curso_laboratorio`;
-- USE `curso_laboratorio`;

-- DROP TABLE tablename1, tablename2, tablename3, tablename4;


-- ----------------------------
-- Table structure for analisis
-- ----------------------------
 
DROP TABLE IF EXISTS `analisis`;
CREATE TABLE `analisis` (
  `analisis_id` int(11) NOT NULL AUTO_INCREMENT,
  `analisis_nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `analisis_fregistro` date DEFAULT NULL,
  `analisis_estatus` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`analisis_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table analisis
-- ----------------------------
 
INSERT INTO `analisis` (`analisis_id`,`analisis_nombre`,`analisis_fregistro`,`analisis_estatus`) VALUES
('1','ORINA','2021-11-30','ACTIVO'),
('2','SANGRE','2021-11-30','ACTIVO'),
('3','PROSTATA','2021-11-30','INACTIVO'),
('4','CORAZON','2021-11-30','ACTIVO');

-- ----------------------------
-- Table structure for especialidad
-- ----------------------------
 
DROP TABLE IF EXISTS `especialidad`;
CREATE TABLE `especialidad` (
  `especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `especialidad_nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `especialidad_fregistro` date DEFAULT NULL,
  `especialidad_estatus` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`especialidad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table especialidad
-- ----------------------------
 
INSERT INTO `especialidad` (`especialidad_id`,`especialidad_nombre`,`especialidad_fregistro`,`especialidad_estatus`) VALUES
('1','PEDIATRA','2021-12-20','ACTIVO'),
('2','PARTO','2021-12-20','INACTIVO'),
('3','MEDECI','2021-12-20','INACTIVO'),
('4','MEDECINA','2021-12-20','ACTIVO'),
('5','CIRUGIA','2021-12-20','ACTIVO');

-- ----------------------------
-- Table structure for examen
-- ----------------------------
 
DROP TABLE IF EXISTS `examen`;
CREATE TABLE `examen` (
  `examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `examen_nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `examen_fregistro` date DEFAULT NULL,
  `analisis_id` int(11) DEFAULT NULL,
  `examen_estatus` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`examen_id`) USING BTREE,
  KEY `analisis_id` (`analisis_id`) USING BTREE,
  CONSTRAINT `examen_ibfk_1` FOREIGN KEY (`analisis_id`) REFERENCES `analisis` (`analisis_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table examen
-- ----------------------------
 
INSERT INTO `examen` (`examen_id`,`examen_nombre`,`examen_fregistro`,`analisis_id`,`examen_estatus`) VALUES
('2','ejem DE SANGRE','2022-01-05','2','ACTIVO'),
('3','CARDIO CORAZZON','2021-12-01','4','ACTIVO'),
('4','BIO ORINA','2021-12-01','1','ACTIVO'),
('6','SANGRE PRUE','2021-12-03','2','INACTIVO'),
('8','CORAZ CARDIO','2021-12-09','4','ACTIVO'),
('9','SANG','2021-12-13','2','ACTIVO'),
('10','EJE ORINA','2021-12-14','1','ACTIVO');

-- ----------------------------
-- Table structure for kardex
-- ----------------------------
 
DROP TABLE IF EXISTS `kardex`;
CREATE TABLE `kardex` (
  `kardex_id` int(11) NOT NULL AUTO_INCREMENT,
  `kardex_fecha` date DEFAULT NULL,
  `kardex_tipo` varchar(255) DEFAULT NULL,
  `kardex_ingreso` varchar(255) DEFAULT NULL,
  `kardex_p_ingreso` decimal(10,2) DEFAULT NULL,
  `kardex_salida` varchar(255) DEFAULT NULL,
  `kardex_p_salida` decimal(10,2) DEFAULT NULL,
  `kardex_total` varchar(255) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`kardex_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
 

-- ----------------------------
-- Table structure for medico
-- ----------------------------
 
DROP TABLE IF EXISTS `medico`;
CREATE TABLE `medico` (
  `medico_id` int(11) NOT NULL AUTO_INCREMENT,
  `medico_nombre` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_apepat` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_apemat` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_direccion` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_movil` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_fenac` date DEFAULT NULL,
  `medico_nrodocumento` char(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `especialidad_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`medico_id`) USING BTREE,
  KEY `especialidad_id` (`especialidad_id`) USING BTREE,
  KEY `usuario_id` (`usuario_id`) USING BTREE,
  CONSTRAINT `medico_ibfk_1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`),
  CONSTRAINT `medico_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table medico
-- ----------------------------
 
INSERT INTO `medico` (`medico_id`,`medico_nombre`,`medico_apepat`,`medico_apemat`,`medico_direccion`,`medico_movil`,`medico_fenac`,`medico_nrodocumento`,`especialidad_id`,`usuario_id`) VALUES
('1','gustavo','masias','salvador','5 DE FEBRERO','78954651','2021-12-20','74859632','1','2'),
('2','JHOAN','MASIAS','FSDFSDF','dfsdfsdf','444444','1992-11-01','33333333','5','6'),
('3','KARINA','MARIBEL','SALVADORR','5 de febrero','926812599','1992-11-01','74859633','4','7'),
('4','MARTIN','JULCA','CORDOBA',' de febrero','45952','1992-01-01','33333334','1','8');

-- ----------------------------
-- Table structure for paciente
-- ----------------------------
 
DROP TABLE IF EXISTS `paciente`;
CREATE TABLE `paciente` (
  `paciente_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_nombres` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_apepaterno` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_apematerno` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_dni` char(8) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_celular` varchar(12) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_edad` int(11) DEFAULT NULL,
  `paciente_edadtipo` char(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `paciente_sexo` enum('M','F') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`paciente_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table paciente
-- ----------------------------
 
INSERT INTO `paciente` (`paciente_id`,`paciente_nombres`,`paciente_apepaterno`,`paciente_apematerno`,`paciente_dni`,`paciente_celular`,`paciente_edad`,`paciente_edadtipo`,`paciente_sexo`) VALUES
('1','JUAN','MASIAS','VILCHES','45454545','78965412','45','M','F'),
('2','KARINA','SALVADOR','JULCA','40003884','123456','49','A','F'),
('3','KARINA','SALVADOR','JULCA','40003863','123456','14','A','F'),
('4','CARLOS MARTIN','JULCA','CORDOVA','75123698','555','45','A','M'),
('5','JUANA MARTINA','JUARES','LOPEZ','12345678','123456','13','A','F'),
('9','AAAA','QQQ','QQQ','1234568','212111','87','M','M'),
('10','DFGDFG','DFGDF','GDFG','33333','333','5','A','M'),
('11','MARIA','VILLEGAS','VILLEGAS','15124632','789654','25','A','F'),
('12','TONY','MORAN','MORAN','47478596','454545454','29','A','M'),
('13','YOSI','PALOMINO','PALOMINO','45485478','7878787','25','A','M'),
('14','JULCA','CORDOVA','CORDOVA','78789569','92568459','53','A','M');

-- ----------------------------
-- Table structure for realizar_examen
-- ----------------------------
 
DROP TABLE IF EXISTS `realizar_examen`;
CREATE TABLE `realizar_examen` (
  `realizarexamen_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `realizarexamen_estatus` enum('PENDIENTE','FINALIZADO') COLLATE utf8_spanish_ci DEFAULT NULL,
  `medico_id` int(11) DEFAULT NULL,
  `realizarexamen_fregistro` date DEFAULT NULL,
  PRIMARY KEY (`realizarexamen_id`) USING BTREE,
  KEY `paciente_id` (`paciente_id`) USING BTREE,
  KEY `usuario_id` (`usuario_id`) USING BTREE,
  KEY `medico_id` (`medico_id`) USING BTREE,
  CONSTRAINT `realizar_examen_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`),
  CONSTRAINT `realizar_examen_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usu_id`),
  CONSTRAINT `realizar_examen_ibfk_4` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table realizar_examen
-- ----------------------------
 
INSERT INTO `realizar_examen` (`realizarexamen_id`,`paciente_id`,`usuario_id`,`realizarexamen_estatus`,`medico_id`,`realizarexamen_fregistro`) VALUES
('1','14','1','PENDIENTE','1','2022-01-17'),
('2','13','1','PENDIENTE','4','2022-01-17');

-- ----------------------------
-- Table structure for realizar_examen_detalle
-- ----------------------------
 
DROP TABLE IF EXISTS `realizar_examen_detalle`;
CREATE TABLE `realizar_examen_detalle` (
  `rdetalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `examen_id` int(11) DEFAULT NULL,
  `analisis_id` int(11) DEFAULT NULL,
  `realizarexamen_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`rdetalle_id`) USING BTREE,
  KEY `examen_id` (`examen_id`) USING BTREE,
  KEY `analisis_id` (`analisis_id`) USING BTREE,
  KEY `realizarexamen_id` (`realizarexamen_id`) USING BTREE,
  CONSTRAINT `realizar_examen_detalle_ibfk_1` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`),
  CONSTRAINT `realizar_examen_detalle_ibfk_2` FOREIGN KEY (`analisis_id`) REFERENCES `analisis` (`analisis_id`),
  CONSTRAINT `realizar_examen_detalle_ibfk_3` FOREIGN KEY (`realizarexamen_id`) REFERENCES `realizar_examen` (`realizarexamen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table realizar_examen_detalle
-- ----------------------------
 
INSERT INTO `realizar_examen_detalle` (`rdetalle_id`,`examen_id`,`analisis_id`,`realizarexamen_id`) VALUES
('1','4','1','1'),
('2','8','4','1'),
('3','4','1','2'),
('4','2','2','2'),
('5','8','4','2');

-- ----------------------------
-- Table structure for resultado
-- ----------------------------
 
DROP TABLE IF EXISTS `resultado`;
CREATE TABLE `resultado` (
  `resultado_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `resultado_fregistro` date DEFAULT NULL,
  `resultado_estatus` char(1) COLLATE utf8_spanish_ci DEFAULT NULL,
  `realizarexamen_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`resultado_id`) USING BTREE,
  KEY `usuario_id` (`usuario_id`) USING BTREE,
  KEY `realizarexamen_id` (`realizarexamen_id`) USING BTREE,
  CONSTRAINT `resultado_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usu_id`),
  CONSTRAINT `resultado_ibfk_3` FOREIGN KEY (`realizarexamen_id`) REFERENCES `realizar_examen` (`realizarexamen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table resultado
-- ----------------------------
 
INSERT INTO `resultado` (`resultado_id`,`usuario_id`,`resultado_fregistro`,`resultado_estatus`,`realizarexamen_id`) VALUES
('2','1','2022-01-17','0','1'),
('4','1','2022-01-17','1','2'),
('5','1','2022-01-18','1','2');

-- ----------------------------
-- Table structure for resultado_detalle
-- ----------------------------
 
DROP TABLE IF EXISTS `resultado_detalle`;
CREATE TABLE `resultado_detalle` (
  `resuldetalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `resultado_id` int(11) DEFAULT NULL,
  `resuldetalle_archivo` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rdetalle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`resuldetalle_id`) USING BTREE,
  KEY `resultado_id` (`resultado_id`) USING BTREE,
  KEY `rdetalle_id` (`rdetalle_id`) USING BTREE,
  CONSTRAINT `resultado_detalle_ibfk_2` FOREIGN KEY (`resultado_id`) REFERENCES `resultado` (`resultado_id`),
  CONSTRAINT `resultado_detalle_ibfk_3` FOREIGN KEY (`rdetalle_id`) REFERENCES `realizar_examen_detalle` (`rdetalle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for rol
-- ----------------------------
 
DROP TABLE IF EXISTS `rol`;
CREATE TABLE `rol` (
  `rol_id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_nombre` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rol_fregistro` date DEFAULT NULL,
  `rol_estatus` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`rol_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table rol
-- ----------------------------
 
INSERT INTO `rol` (`rol_id`,`rol_nombre`,`rol_fregistro`,`rol_estatus`) VALUES
('1','Admin','2021-11-16','ACTIVO'),
('3','empleado','2021-11-29','ACTIVO'),
('8','Jefe laboratorio','2021-12-20','ACTIVO');

-- ----------------------------
-- Table structure for usuario
-- ----------------------------
 
DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `usu_id` int(11) NOT NULL AUTO_INCREMENT,
  `usu_nombre` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usu_contrasena` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `usu_status` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci DEFAULT NULL,
  `usu_email` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usu_foto` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`usu_id`) USING BTREE,
  KEY `rol_id` (`rol_id`) USING BTREE,
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`rol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table usuario
-- ----------------------------
 
INSERT INTO `usuario` (`usu_id`,`usu_nombre`,`usu_contrasena`,`rol_id`,`usu_status`,`usu_email`,`usu_foto`) VALUES
('1','gustavo','$2y$12$jvYOrLk7BMDGBpYeE/KIPeRwtOYjv9gsU0zlnsdUj0KhCGl.wcmfK','1','ACTIVO','','controller/usuario/foto/default.png'),
('2','juan','$2y$12$s2Ne2MPBVdDQmnzYrRF.qO8aLlBFJy0PsgfB8pmyncT18/DBZkJau','1','ACTIVO','','controller/usuario/foto/default.png'),
('3','ARODRIGUES','123456','3','ACTIVO','SDSDSD@GMAIL.COM','controller/usuario/foto/IMG2112202117358.jpg'),
('4','SSSD','sdsdsd','8','INACTIVO','SDASDAS@GMAIL.COM','controller/usuario/foto/default.png'),
('5','ASAS','15142','8','INACTIVO','SDSDS@GMAI.COM','controller/usuario/foto/default.png'),
('6','SAAAAA','aaaaa','8','INACTIVO','AAAAAAA','controller/usuario/foto/default.png'),
('7','AAAA','aaa','3','INACTIVO','AAAA','controller/usuario/foto/default.png'),
('8','MARTIN','123456','3','ACTIVO','ASAASAS','controller/usuario/foto/default.png'),
('9','qqqqqqq','$2y$12$Y6Un6av5iJDNoqURUGuKnO.E56aNZKf9xdHD9FB171veRx78Uv.RK','8','INACTIVO','qqqq','controller/usuario/foto/IMG2112202117815.png');
/*{
-- ============================================== VIEWS ================================================
-- ----------------------------
-- View structure for view_listar paciente_examen
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar paciente_examen`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar paciente_examen` AS select `realizar_examen`.`realizarexamen_id` AS `realizarexamen_id`,`realizar_examen`.`paciente_id` AS `paciente_id`,concat_ws(' ',`paciente`.`paciente_apepaterno`,`paciente`.`paciente_apematerno`,`paciente`.`paciente_nombres`) AS `paciente`,`paciente`.`paciente_dni` AS `dnip`,`paciente`.`paciente_edad` AS `edadp`,`realizar_examen`.`realizarexamen_estatus` AS `estado`,`realizar_examen`.`medico_id` AS `medico_id`,concat_ws(' ',`medico`.`medico_apepat`,`medico`.`medico_apemat`,`medico`.`medico_nombre`) AS `medico` from ((`realizar_examen` join `paciente` on(`realizar_examen`.`paciente_id` = `paciente`.`paciente_id`)) join `medico` on(`realizar_examen`.`medico_id` = `medico`.`medico_id`)) where `realizar_examen`.`realizarexamen_estatus` = 'PENDIENTE';
-- ----------------------------
-- View structure for view_listar_paciente
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_paciente`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_paciente` AS select `paciente`.`paciente_id` AS `paciente_id`,`paciente`.`paciente_nombres` AS `paciente_nombres`,`paciente`.`paciente_apepaterno` AS `paciente_apepaterno`,`paciente`.`paciente_apematerno` AS `paciente_apematerno`,`paciente`.`paciente_dni` AS `paciente_dni`,`paciente`.`paciente_celular` AS `paciente_celular`,`paciente`.`paciente_edad` AS `paciente_edad`,`paciente`.`paciente_edadtipo` AS `paciente_edadtipo`,`paciente`.`paciente_sexo` AS `paciente_sexo`,concat_ws(' ',`paciente`.`paciente_apepaterno`,`paciente`.`paciente_apematerno`,`paciente`.`paciente_nombres`) AS `paciente`,concat_ws(' ',`paciente`.`paciente_edad`,`paciente`.`paciente_edadtipo`) AS `edadcon` from `paciente`;
-- ----------------------------
-- View structure for view_listar_realizarexa
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_realizarexa`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_realizarexa` AS select `realizar_examen`.`realizarexamen_id` AS `realizarexamen_id`,`paciente`.`paciente_dni` AS `paciente_dni`,concat_ws(' ',`paciente`.`paciente_apepaterno`,`paciente`.`paciente_apematerno`,`paciente`.`paciente_nombres`) AS `paciente`,concat_ws(' ',`medico`.`medico_apepat`,`medico`.`medico_apemat`,`medico`.`medico_nombre`) AS `medico`,`realizar_examen`.`realizarexamen_fregistro` AS `fecha`,`usuario`.`usu_nombre` AS `usuario`,`realizar_examen`.`realizarexamen_estatus` AS `estado` from (((`realizar_examen` join `paciente` on(`realizar_examen`.`paciente_id` = `paciente`.`paciente_id`)) join `usuario` on(`realizar_examen`.`usuario_id` = `usuario`.`usu_id`)) join `medico` on(`realizar_examen`.`medico_id` = `medico`.`medico_id`));
-- ----------------------------
-- View structure for view_listar_usuario
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_usuario`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_usuario` AS select `usuario`.`usu_id` AS `usu_id`,`usuario`.`usu_nombre` AS `usu_nombre`,`usuario`.`usu_contrasena` AS `usu_contrasena`,`usuario`.`rol_id` AS `rol_id`,`rol`.`rol_nombre` AS `rol_nombre`,`usuario`.`usu_status` AS `usu_status`,`usuario`.`usu_email` AS `usu_email`,`usuario`.`usu_foto` AS `usu_foto` from (`usuario` join `rol` on(`usuario`.`rol_id` = `rol`.`rol_id`));
-- ----------------------------
-- View structure for view_resultado_examen
-- ----------------------------
 
DROP VIEW IF EXISTS `view_resultado_examen`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_resultado_examen` AS select `resultado`.`resultado_id` AS `resultado_id`,concat_ws(' ',`paciente`.`paciente_apepaterno`,`paciente`.`paciente_apematerno`,`paciente`.`paciente_nombres`) AS `paciente`,`paciente`.`paciente_dni` AS `dni`,`usuario`.`usu_nombre` AS `usuario`,`resultado`.`resultado_fregistro` AS `fecha`,`resultado`.`resultado_estatus` AS `estado` from (((`resultado` join `usuario` on(`resultado`.`usuario_id` = `usuario`.`usu_id`)) join `realizar_examen` on(`resultado`.`realizarexamen_id` = `realizar_examen`.`realizarexamen_id`)) join `paciente` on(`realizar_examen`.`paciente_id` = `paciente`.`paciente_id`));

-- ============================================== PROCEDURES ================================================
-- ----------------------------
-- Procedure structure for LLENARDATA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `LLENARDATA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `LLENARDATA`()
BEGIN
DECLARE CONTADOR INT;
SET @CONTADOR=1500;
WHILE 4000>@CONTADOR DO
	INSERT INTO usuario(usu_nombre,usu_contrasena,rol_id,usu_status,usu_email)VALUES
	(CONCAT_WS('','gustavo',@CONTADOR),'$2y$12$.Hk4LP7ITDk4BV2dU6OwkuS1iKoktJwKVanE9rF7OvekESf6f8tgS','1','ACTIVO',CONCAT_WS('','luiyi',@CONTADOR,'@gmail.com'));
	SET @CONTADOR:=@CONTADOR+1;
END WHILE;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ANALISIS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ANALISIS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ANALISIS`()
SELECT
	analisis.analisis_id, 
	analisis.analisis_nombre, 
	analisis.analisis_fregistro, 
	analisis.analisis_estatus
FROM
	analisis ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ANALISIS2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ANALISIS2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ANALISIS2`()
SELECT
	analisis.analisis_id, 
	analisis.analisis_nombre, 
	analisis.analisis_fregistro, 
	analisis.analisis_estatus
FROM
	analisis ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_DETALLE_ANALISIS_RESULTADO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_DETALLE_ANALISIS_RESULTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_DETALLE_ANALISIS_RESULTADO`(IN IDANALI INT)
SELECT
	realizar_examen_detalle.rdetalle_id, 
	realizar_examen_detalle.examen_id, 
	realizar_examen_detalle.analisis_id, 
	examen.examen_nombre, 
	analisis.analisis_nombre
FROM
	realizar_examen_detalle
	INNER JOIN
	analisis
	
	ON 
		realizar_examen_detalle.analisis_id = analisis.analisis_id
		
	INNER JOIN
	examen
	ON 
		realizar_examen_detalle.examen_id = examen.examen_id
		where realizar_examen_detalle.realizarexamen_id = IDANALI ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ESPECIALIDAD2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ESPECIALIDAD2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ESPECIALIDAD2`()
SELECT
	especialidad.especialidad_id, 
	especialidad.especialidad_nombre, 
	especialidad.especialidad_fregistro, 
	especialidad.especialidad_estatus
FROM
	especialidad ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_EXAMEN
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_EXAMEN`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_EXAMEN`()
SELECT
	examen.examen_id, 
	examen.examen_nombre, 
	analisis.analisis_nombre, 
	examen.examen_fregistro, 
	examen.examen_estatus, 
	examen.analisis_id
FROM
	examen
	INNER JOIN
	analisis
	ON 
		examen.analisis_id = analisis.analisis_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_EXAMEN2`()
SELECT
	examen.examen_id, 
	examen.examen_nombre, 
	examen.analisis_id, 
	analisis.analisis_nombre, 
	examen.examen_fregistro, 
	examen.examen_estatus
FROM
	examen
	INNER JOIN
	analisis
	ON 
		examen.analisis_id = analisis.analisis_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_MEDICO2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_MEDICO2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_MEDICO2`()
SELECT
	medico.medico_id, 
	medico.medico_nombre, 
	medico.medico_apepat, 
	medico.medico_apemat, 
	medico.medico_direccion, 
	medico.medico_movil, 
	medico.medico_fenac, 
	medico.medico_nrodocumento, 
	especialidad.especialidad_nombre,
	especialidad.especialidad_id,
		CONCAT_WS(' ',medico_apepat,medico_apemat,medico_nombre) as nombrec
FROM
	medico
	INNER JOIN
	especialidad
	ON 
		medico.especialidad_id = especialidad.especialidad_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ROL`()
SELECT
	rol.rol_id, 
	rol.rol_nombre, 
	rol.rol_fregistro, 
	rol.rol_estatus
FROM
	rol ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ROL2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ROL2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ROL2`()
SELECT rol_id,rol_nombre, rol_fregistro, rol_estatus 
FROM rol ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ANALISIS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ANALISIS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ANALISIS`()
SELECT analisis_id,analisis_nombre FROM analisis WHERE analisis_estatus='ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ANALISIS2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ANALISIS2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ANALISIS2`()
SELECT
	analisis_id, 
	analisis_nombre
FROM
	analisis
WHERE 
	analisis_estatus = 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ESPECIALIDAD2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ESPECIALIDAD2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ESPECIALIDAD2`()
SELECT
	especialidad_id, 
	especialidad_nombre
FROM
	especialidad
WHERE 
	especialidad_estatus = 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_EXAMEN2`(IN IDANA INT)
select examen_id, examen_nombre from examen where analisis_id = IDANA ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ROL`()
SELECT * FROM ROL ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_USUARIO`()
SELECT
	usuario.usu_id, 
	usuario.usu_nombre, 
	usuario.usu_contrasena, 
	usuario.rol_id, 
	usuario.usu_status, 
	usuario.usu_email, 
	usuario.usu_foto, 
	rol.rol_nombre
FROM
	usuario
	INNER JOIN
	rol
	ON 
		usuario.rol_id = rol.rol_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_USUARIO_SIMPLE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_USUARIO_SIMPLE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_USUARIO_SIMPLE`()
SELECT
	usuario.usu_id, 
	usuario.usu_nombre, 
	usuario.usu_contrasena, 
	usuario.rol_id, 
	usuario.usu_status, 
	usuario.usu_email, 
	usuario.usu_foto, 
	rol.rol_nombre
FROM
	usuario
	INNER JOIN
	rol
	ON 
		usuario.rol_id = rol.rol_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ANALISIS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ANALISIS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ANALISIS`(IN ID INT,IN ANALISIS VARCHAR(100),IN ESTATUS VARCHAR(10))
BEGIN
DECLARE ANALISISACTUAL VARCHAR(100);
DECLARE CANTIDAD INT;
SET @ANALISISACTUAL:=(SELECT analisis_nombre from analisis where analisis_id=ID);
if @ANALISISACTUAL = ANALISIS THEN
	UPDATE analisis set
	analisis_nombre=ANALISIS,
	analisis_estatus=ESTATUS
	WHERE analisis_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) from analisis where analisis_nombre=ANALISIS);
	IF @CANTIDAD = 0 THEN
		UPDATE analisis set
		analisis_nombre=ANALISIS,
		analisis_estatus=ESTATUS
		WHERE analisis_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ANALISIS2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ANALISIS2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ANALISIS2`(IN ID INT,IN ANALISIS VARCHAR(100), IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANT INT;
DECLARE ANALIACTUAL INT;
SET @ANALIACTUAL:= (SELECT analisis_nombre FROM analisis WHERE analisis_id = ID);
IF @ANALIACTUAL = ANALISIS THEN
	UPDATE analisis SET
	analisis_nombre =  ANALISIS,
	analisis_estatus = ESTADO
	WHERE analisis_id = ID;
	SELECT 1;
ELSE
	SET @CANT:= (SELECT COUNT(*) analisis FROM analisis WHERE analisis_nombre = ANALISIS);
	IF @CANT = 0 THEN
		UPDATE analisis SET
		analisis_nombre =  ANALISIS,
		analisis_estatus = ESTADO
		WHERE analisis_id = ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_CLAVE_USUARIO2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_CLAVE_USUARIO2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_CLAVE_USUARIO2`(IN ID INT, IN CLAVE VARCHAR(255))
UPDATE usuario SET
usu_contrasena = CLAVE
WHERE usu_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ESPECIALIDAD2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ESPECIALIDAD2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ESPECIALIDAD2`(IN ID INT, IN ESPECIALIDAD VARCHAR(25), IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANT INT;
DECLARE ESPECIALIDADACTUAL VARCHAR(25);
SET @ESPECIALIDADACTUAL:=(SELECT especialidad_nombre from especialidad where especialidad_id=ID);
IF  @ESPECIALIDADACTUAL = ESPECIALIDAD THEN
	UPDATE especialidad SET
	especialidad_nombre = ESPECIALIDAD,
	especialidad_estatus = ESTADO
	WHERE especialidad_id = ID;
	SELECT 1;
ELSE
	SET @CANT:=(SELECT COUNT(*) FROM especialidad where especialidad_nombre=ESPECIALIDAD);
	if @CANT = 0 THEN
		UPDATE especialidad SET
		especialidad_nombre = ESPECIALIDAD,
		especialidad_estatus = ESTADO
		WHERE especialidad_id = ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_EXAMEN2`(IN ID INT, IN EXAMEN VARCHAR(100), IN ANALISIS INT, IN ESTADO VARCHAR(10))
BEGIN
DECLARE EXAMENACTUAL VARCHAR(100);
DECLARE CANTIDAD INT;
SET @EXAMENACTUAL:=(SELECT examen_nombre from examen where examen_id=ID);
if @EXAMENACTUAL = EXAMEN THEN
	UPDATE examen set
	examen_nombre=EXAMEN,
	analisis_id=ANALISIS,
	examen_estatus=ESTADO
	WHERE examen_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) from examen where examen_nombre=EXAMEN and analisis_id=ANALISIS);
	IF @CANTIDAD = 0 THEN
		UPDATE examen set
	examen_nombre=EXAMEN,
	analisis_id=ANALISIS,
	examen_estatus=ESTADO
	WHERE examen_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_FOTO_USUARIO2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_FOTO_USUARIO2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_FOTO_USUARIO2`(IN ID INT, IN RUTA VARCHAR(255))
UPDATE usuario SET
usu_foto = RUTA
WHERE usu_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_MEDICO2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_MEDICO2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_MEDICO2`(IN ID INT,IN DNI CHAR(8),IN NOMBRES VARCHAR(100),IN APEPAT VARCHAR(100),IN APEMAT VARCHAR(100),IN CELULAR VARCHAR(12),IN DIRECCION VARCHAR(255),IN ESPECIALIDAD INT,IN FECHA DATE)
BEGIN 

DECLARE CANT INT;
DECLARE DNIACTUAL INT;

SET @DNIACTUAL:=(SELECT medico_nrodocumento FROM medico WHERE medico_id = ID);
IF @DNIACTUAL = DNI THEN
	UPDATE medico SET
	medico_nombre = NOMBRES,
	medico_apepat = APEPAT,
	medico_apemat= APEMAT,
	medico_movil = CELULAR,
	medico_direccion = DIRECCION,
	especialidad_id = ESPECIALIDAD,
	medico_fenac = FECHA
	WHERE medico_id = ID;
	SELECT 1;
ELSE
	SET @CANT:=(SELECT COUNT(*) FROM medico WHERE medico_nrodocumento = DNI);
	IF @CANT = 0 THEN
	UPDATE medico SET
	medico_nrodocumento = DNI,
	medico_nombre = NOMBRES,
	medico_apepat = APEPAT,
	medico_apemat= APEMAT,
	medico_movil = CELULAR,
	medico_direccion = DIRECCION,
	especialidad_id = ESPECIALIDAD,
	medico_fenac = FECHA
	WHERE medico_id = ID;
		SELECT 1;
	
	ELSE
		SELECT 2;
	END IF;

END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_PACIENTE2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_PACIENTE2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_PACIENTE2`(IN ID INT,IN NOMBRES VARCHAR(100),IN APEPAT VARCHAR(100),IN APEMAT VARCHAR(100),IN EDAD INT(11),IN DNI VARCHAR(10),IN CELULAR VARCHAR(12),IN TIPOE VARCHAR(10),IN SEXO VARCHAR(12))
BEGIN
DECLARE PACIENTEACTUAL VARCHAR(100);
DECLARE CANTIDAD INT;
SET @PACIENTEACTUAL:=(SELECT paciente_dni from paciente where paciente_id=ID and paciente_dni= DNI);
if @PACIENTEACTUAL = DNI THEN
	UPDATE paciente set
	paciente_nombres=NOMBRES,
	paciente_apepaterno=APEPAT,
	paciente_apematerno=APEMAT,
	paciente_dni=DNI,
	paciente_celular=CELULAR,
	paciente_edad=EDAD,
	paciente_edadtipo=TIPOE,
	paciente_sexo=SEXO
	WHERE paciente_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) from paciente where paciente_dni=DNI);
	IF @CANTIDAD = 0 THEN
		UPDATE paciente set
		paciente_nombres=NOMBRES,
		paciente_apepaterno=APEPAT,
		paciente_apematerno=APEMAT,
		paciente_dni=DNI,
		paciente_celular=CELULAR,
		paciente_edad=EDAD,
		paciente_edadtipo=TIPOE,
		paciente_sexo=SEXO
		WHERE paciente_id=ID;
			SELECT 1;
	ELSE
			SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ROL`(IN ID INT,IN ROL VARCHAR(25),IN ESTATUS VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE ROLACTUAL VARCHAR(25);
SET @ROLACTUAL:=(SELECT rol_nombre from rol where rol_id=ID);
IF @ROLACTUAL = ROL THEN
	UPDATE rol set
	rol_nombre=ROL,
	rol_estatus=ESTATUS
	where rol_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM rol where rol_nombre=ROL);
	if @CANTIDAD = 0 THEN
		UPDATE rol set
		rol_nombre=ROL,
		rol_estatus=ESTATUS
		where rol_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ROL2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ROL2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ROL2`(IN ID INT, IN ROL VARCHAR(25), IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANT INT;
DECLARE ROLACTUAL VARCHAR(25);
SET @ROLACTUAL:=(SELECT rol_nombre from rol where rol_id=ID);
IF @ROLACTUAL = ROL THEN
	UPDATE rol SET
	rol_nombre = ROL,
	rol_estatus = ESTADO
	WHERE rol_id = ID;
	SELECT 1;
ELSE
	SET @CANT:=(SELECT COUNT(*) FROM rol where rol_nombre=ROL);
	if @CANT = 0 THEN
			UPDATE rol SET
			rol_nombre = ROL,
			rol_estatus = ESTADO
			WHERE rol_id = ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO`(IN ID INT,IN EMAIL VARCHAR(255),IN ROL INT)
UPDATE usuario set
usu_email=EMAIL,
rol_id=ROL
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIOS2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIOS2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIOS2`(IN ID INT, IN USUARIO VARCHAR(20), IN CORREO VARCHAR(255), IN ROL INT)
UPDATE usuario SET
usu_email = CORREO,
usu_nombre = USUARIO,
rol_id = ROL
WHERE usu_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIOS2_ESTADO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIOS2_ESTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIOS2_ESTADO`(IN ID INT, IN ESTADO VARCHAR(20))
UPDATE usuario SET
usu_status = ESTADO
WHERE usu_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO_CONTRA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO_CONTRA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO_CONTRA`(IN ID INT,IN CONTRA VARCHAR(255))
UPDATE usuario set
usu_contrasena=CONTRA
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO_ESTATUS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO_ESTATUS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO_ESTATUS`(IN ID INT,IN ESTATUS VARCHAR(10))
UPDATE usuario set
usu_status=ESTATUS
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO_FOTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO_FOTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO_FOTO`(IN ID INT,IN RUTA VARCHAR(255))
UPDATE usuario set
usu_foto=RUTA
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ANALIS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ANALIS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ANALIS`(IN ANALISIS VARCHAR(100))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) from analisis where analisis_nombre=ANALISIS);
IF @CANTIDAD = 0 THEN
	INSERT INTO analisis(analisis_nombre,analisis_fregistro,analisis_estatus)VALUES(ANALISIS,CURDATE(),'ACTIVO');
	SELECT 1;
ELSE
	SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ANALISIS2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ANALISIS2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ANALISIS2`(IN ANALISIS VARCHAR(100))
BEGIN
DECLARE CANT INT;
SET @CANT:= (SELECT COUNT(*) FROM analisis WHERE analisis_nombre = ANALISIS);
IF @CANT = 0 THEN
	INSERT INTO analisis(analisis_nombre, analisis_fregistro, analisis_estatus)VALUES (ANALISIS, CURDATE(), 'ACTIVO');
	SELECT 1;
ELSE
  SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN`(IN ID INT,IN IDEXAMEN INT,IN IDANALISIS INT)
INSERT INTO realizar_examen_detalle(examen_id,analisis_id,realizarexamen_id)VALUES(IDEXAMEN,IDANALISIS,ID) ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_DETALLE_REALIZAR_EXAMEN2`(IN IDCAB INT, IN IDEXAMEN INT, IN IDANALI INT)
INSERT INTO realizar_examen_detalle (realizarexamen_id,examen_id, analisis_id)
	VALUES (IDCAB,IDEXAMEN,IDANALI) ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ESPECIALIDAD2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ESPECIALIDAD2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ESPECIALIDAD2`(IN ESPECIALIDAD VARCHAR(25))
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM especialidad WHERE especialidad_nombre = BINARY ESPECIALIDAD );
IF	@CANT = 0 THEN
		INSERT INTO especialidad(especialidad_nombre,especialidad_fregistro,especialidad_estatus)
		VALUES(ESPECIALIDAD, CURDATE(),'ACTIVO');
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_EXAMEN
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_EXAMEN`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_EXAMEN`(IN EXAMEN VARCHAR(100),IN IDANALISIS INT)
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM examen where examen_nombre=EXAMEN and analisis_id=IDANALISIS);
IF @CANTIDAD = 0 THEN
	INSERT INTO examen(examen_nombre,analisis_id,examen_fregistro,examen_estatus) VALUES(EXAMEN,IDANALISIS,CURDATE(),'ACTIVO');
	SELECT 1;
ELSE
	SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_EXAMEN2`(IN EXAMEN VARCHAR(100),IN IDANALISIS INT)
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM  examen WHERE examen_nombre = EXAMEN AND analisis_id = IDANALISIS);
IF @CANT = 0 THEN
	INSERT INTO examen (examen_nombre, analisis_id, examen_fregistro, examen_estatus) VALUES (EXAMEN, IDANALISIS, CURDATE(), 'ACTIVO');
	SELECT 1;
ELSE
 SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_MEDICO2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_MEDICO2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_MEDICO2`(IN DNI CHAR(8),IN NOMBRES VARCHAR(100),IN APEPAT VARCHAR(100),IN APEMAT VARCHAR(100),IN CELULAR VARCHAR(12),IN DIRECCION VARCHAR(255),IN ESPECIALIDAD INT,IN FECHA DATE,IN USUARIO VARCHAR(20), IN CLAVE VARCHAR(255),IN CORREO VARCHAR(255),IN ROL INT)
BEGIN 
DECLARE CANTUSER INT;
DECLARE CANTMEDICO INT;
SET @CANTUSER:=(SELECT COUNT(*) FROM usuario WHERE usu_nombre = USUARIO);
IF @CANTUSER = 0 THEN
	SET @CANTMEDICO:=(SELECT COUNT(*) FROM medico WHERE medico_nrodocumento = DNI);
	IF @CANTMEDICO = 0 THEN
		INSERT INTO usuario(usu_nombre, usu_contrasena, usu_email, rol_id, usu_foto, usu_status)
		VALUES(USUARIO, CLAVE, CORREO, ROL, '','ACTIVO');
			INSERT INTO medico (medico_nrodocumento, medico_nombre, medico_apepat, medico_apemat, medico_movil, medico_direccion, especialidad_id, medico_fenac, usuario_id) 
			VALUES(DNI, NOMBRES, APEPAT, APEMAT, CELULAR, DIRECCION, ESPECIALIDAD, FECHA, (SELECT MAX(usu_id) FROM USUARIO));
			SELECT 1;
	ELSE 
		SELECT 2;
	END IF;
ELSE
	SELECT 3;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_PACIENTE2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_PACIENTE2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_PACIENTE2`(IN NOMBRES VARCHAR(100),IN APEPAT VARCHAR(100),IN APEMAT VARCHAR(100),IN EDAD INT(11),IN DNI VARCHAR(10),IN CELULAR VARCHAR(12),IN TIPOE VARCHAR(10),IN SEXO VARCHAR(12))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM paciente where paciente_dni=DNI);
IF @CANTIDAD = 0 THEN
	INSERT INTO paciente(paciente_nombres,paciente_apepaterno,paciente_apematerno,paciente_edad,paciente_dni,paciente_celular,paciente_edadtipo,paciente_sexo) 
	VALUES(NOMBRES,APEPAT,APEMAT,EDAD,DNI,CELULAR,TIPOE,SEXO);
	SELECT 1;
ELSE
	SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_REALIZAR_EXAMEN2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_REALIZAR_EXAMEN2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_REALIZAR_EXAMEN2`(IN IDPAC INT, IN IDUSU INT, IN IDME INT)
BEGIN
	INSERT INTO realizar_examen (paciente_id,usuario_id,realizarexamen_estatus,medico_id,realizarexamen_fregistro)
	VALUES (IDPAC, IDUSU, 'PENDIENTE', IDME, CURDATE());
	SELECT LAST_INSERT_ID();
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_RESULTADO_EXAMEN
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_RESULTADO_EXAMEN`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_RESULTADO_EXAMEN`(IN IDRESULEXAMEN INT, IN IDUSUARIO INT)
BEGIN
INSERT INTO resultado (usuario_id,resultado_fregistro,resultado_estatus,realizarexamen_id)
VALUES (IDUSUARIO,CURDATE(), '1',IDRESULEXAMEN );
SELECT LAST_INSERT_ID();
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ROL`(IN ROL VARCHAR(25))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM rol where rol_nombre=ROL);
if @CANTIDAD = 0 THEN
INSERT into rol(rol_nombre,rol_fregistro,rol_estatus)values(ROL,CURDATE(),'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ROL2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ROL2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ROL2`(IN ROL VARCHAR(25))
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM rol WHERE rol_nombre = BINARY ROL );
IF	@CANT = 0 THEN
		INSERT INTO rol(rol_nombre,rol_fregistro,rol_estatus)
		VALUES(ROL, CURDATE(),'ACTIVO');
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_USUARIO`(IN USUARIO VARCHAR(20),IN CONTRA VARCHAR(255),IN EMAIL VARCHAR(255),
IN ROL INT,IN RUTA VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) from usuario where usu_nombre = BINARY USUARIO);
IF @CANTIDAD = 0 THEN
	INSERT INTO usuario(usu_nombre,usu_contrasena,usu_email,rol_id,usu_foto,usu_status)
	VALUES(USUARIO,CONTRA,EMAIL,ROL,RUTA,'ACTIVO');
	SELECT 1;
ELSE
	SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_USUARIOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_USUARIOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_USUARIOS`(IN USUARIO VARCHAR(20), IN CLAVE VARCHAR(255),IN CORREO VARCHAR(255),IN ROL INT,IN RUTA VARCHAR(255))
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM usuario WHERE usu_nombre = BINARY USUARIO);
IF @CANT = 0 THEN
	INSERT INTO usuario(usu_nombre, usu_contrasena, usu_email, rol_id, usu_foto, usu_status)
	VALUES(USUARIO, CLAVE, CORREO, ROL, RUTA,'ACTIVO');
	SELECT 1;
ELSE
	SELECT 2;
END IF;



END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_VERIFICAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_VERIFICAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_VERIFICAR_USUARIO`(IN USUARIO VARCHAR(250))
SELECT
	usuario.usu_id, 
	usuario.usu_nombre, 
	usuario.usu_contrasena, 
	usuario.rol_id, 
	usuario.usu_status, 
	usuario.usu_email, 
	usuario.usu_foto, 
	rol.rol_nombre
FROM
	usuario
	INNER JOIN
	rol
	ON 
		usuario.rol_id = rol.rol_id
where usu_nombre = BINARY USUARIO ;; 
DELIMITER ; 
}*/
-- ================================== END DATABASE curso_laboratorio ========================================

 
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
