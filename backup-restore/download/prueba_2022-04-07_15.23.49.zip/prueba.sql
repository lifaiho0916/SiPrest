/*{------------------------------------------------------------------------
|  MySQL Database Backup DumpDB
|
|  Host: localhost    Database: prueba    CreateAt: 2022-04-07 15:23:48
|
|  Server: version 10.4.22-MariaDB
|
|  Author of DumpDB: < gil_yeung@outlook.com > Gilberto Villarreal Rodriguez 
*-------------------------------------------------------------------------}*/
 

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;


-- ================================== BEGIN DATABASE prueba =======================================
-- DROP DATABASE IF EXISTS `prueba`;
-- CREATE DATABASE `prueba`;
-- USE `prueba`;

-- DROP TABLE tablename1, tablename2, tablename3, tablename4;


-- ----------------------------
-- Table structure for categoria
-- ----------------------------
 
DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria` (
  `categoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_descripcion` varchar(255) DEFAULT NULL,
  `categoria_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`categoria_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table categoria
-- ----------------------------
 
INSERT INTO `categoria` (`categoria_id`,`categoria_descripcion`,`categoria_estado`) VALUES
('1','Celulares','ACTIVO'),
('2','Laptop','ACTIVO'),
('3','General','ACTIVO');

-- ----------------------------
-- Table structure for cliente
-- ----------------------------
 
DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_nombres` varchar(255) DEFAULT NULL,
  `cliente_celular` varchar(255) DEFAULT NULL,
  `cliente_dni` varchar(255) DEFAULT NULL,
  `cliente_fregistro` date DEFAULT NULL,
  `cliente_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `cliente_direccion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cliente_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table cliente
-- ----------------------------
 
INSERT INTO `cliente` (`cliente_id`,`cliente_nombres`,`cliente_celular`,`cliente_dni`,`cliente_fregistro`,`cliente_estado`,`cliente_direccion`) VALUES
('1','Gustavo masias','926812599','71985463','2022-02-15','ACTIVO','Paita piura');

-- ----------------------------
-- Table structure for comprobante
-- ----------------------------
 
DROP TABLE IF EXISTS `comprobante`;
CREATE TABLE `comprobante` (
  `compro_id` int(11) NOT NULL AUTO_INCREMENT,
  `compro_tipo` varchar(255) DEFAULT NULL,
  `compro_serie` varchar(255) DEFAULT NULL,
  `compro_numero` varchar(255) DEFAULT NULL,
  `compro_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`compro_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table comprobante
-- ----------------------------
 
INSERT INTO `comprobante` (`compro_id`,`compro_tipo`,`compro_serie`,`compro_numero`,`compro_estado`) VALUES
('1','BOLETA','B001','1','ACTIVO'),
('2','FACTURA','F001','1','ACTIVO'),
('3','TICKET','0001','1','ACTIVO'),
('4','COTIZACION','0000','00001','ACTIVO');

-- ----------------------------
-- Table structure for configuracion
-- ----------------------------
 
DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `confi_id` int(11) NOT NULL AUTO_INCREMENT,
  `confi_razon_social` varchar(255) DEFAULT NULL,
  `confi_ruc` varchar(255) DEFAULT NULL,
  `confi_nombre_representante` varchar(255) DEFAULT NULL,
  `confi_direccion` varchar(255) DEFAULT NULL,
  `confi_celular` varchar(255) DEFAULT NULL,
  `confi_telefono` varchar(255) DEFAULT NULL,
  `confi_correo` varchar(255) DEFAULT NULL,
  `config_foto` varchar(255) DEFAULT NULL,
  `confi_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `confi_url` varchar(255) DEFAULT NULL,
  `confi_cnta01` varchar(255) DEFAULT NULL,
  `confi_nro_cuenta01` varchar(255) DEFAULT NULL,
  `confi_cnta02` varchar(255) DEFAULT NULL,
  `confi_nro_cuenta02` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`confi_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table configuracion
-- ----------------------------
 
INSERT INTO `configuracion` (`confi_id`,`confi_razon_social`,`confi_ruc`,`confi_nombre_representante`,`confi_direccion`,`confi_celular`,`confi_telefono`,`confi_correo`,`config_foto`,`confi_estado`,`confi_url`,`confi_cnta01`,`confi_nro_cuenta01`,`confi_cnta02`,`confi_nro_cuenta02`) VALUES
('3','MI TIENDA DE CELULARES','1020305648','CARLOS JUAREZ','PIURA - AV NUEVO POR VENIR','989878654','725632','CORREO@GMAIL.COM','controller/empresa/foto/LOGO242202212166.png','ACTIVO','https://santamonicafishing.com/sertec/view/buscar_equipo.php','INTERBANK','2548-1463-1263-7895','BCP','4562-78963-45612-3365');

-- ----------------------------
-- Table structure for cotizacion
-- ----------------------------
 
DROP TABLE IF EXISTS `cotizacion`;
CREATE TABLE `cotizacion` (
  `coti_id` int(11) NOT NULL AUTO_INCREMENT,
  `prove_id` int(11) DEFAULT NULL,
  `coti_comprobante` varchar(255) DEFAULT NULL,
  `coti_serie` varchar(255) DEFAULT NULL,
  `coti_num_comprobante` varchar(255) DEFAULT NULL,
  `coti_total` decimal(10,2) DEFAULT NULL,
  `coti_impuesto` decimal(10,2) DEFAULT NULL,
  `coti_fregistro` date DEFAULT NULL,
  `coti_hora` time DEFAULT NULL,
  `coti_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `compro_id` int(11) DEFAULT NULL,
  `coti_porcentaje` decimal(10,2) DEFAULT NULL,
  `usu_id` int(11) DEFAULT NULL,
  `coti_atiende` varchar(255) DEFAULT NULL,
  `coti_dias` varchar(255) DEFAULT NULL,
  `fpago_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`coti_id`) USING BTREE,
  KEY `prove_id` (`prove_id`) USING BTREE,
  KEY `compro_id` (`compro_id`) USING BTREE,
  KEY `usu_id` (`usu_id`) USING BTREE,
  KEY `fpago_id` (`fpago_id`) USING BTREE,
  CONSTRAINT `cotizacion_ibfk_1` FOREIGN KEY (`prove_id`) REFERENCES `proveedor` (`prove_id`),
  CONSTRAINT `cotizacion_ibfk_2` FOREIGN KEY (`compro_id`) REFERENCES `comprobante` (`compro_id`),
  CONSTRAINT `cotizacion_ibfk_3` FOREIGN KEY (`usu_id`) REFERENCES `usuario` (`usu_id`),
  CONSTRAINT `cotizacion_ibfk_4` FOREIGN KEY (`fpago_id`) REFERENCES `forma_pago` (`fpago_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for cotizacion_detalle
-- ----------------------------
 
DROP TABLE IF EXISTS `cotizacion_detalle`;
CREATE TABLE `cotizacion_detalle` (
  `coti_detalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `coti_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `coti_detalle_cantidad` decimal(10,2) DEFAULT NULL,
  `coti_detalle_precio` decimal(10,2) DEFAULT NULL,
  `coti_detalle_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `coti_detalle_fecha` date DEFAULT NULL,
  PRIMARY KEY (`coti_detalle_id`) USING BTREE,
  KEY `coti_id` (`coti_id`) USING BTREE,
  KEY `producto_id` (`producto_id`) USING BTREE,
  CONSTRAINT `cotizacion_detalle_ibfk_1` FOREIGN KEY (`coti_id`) REFERENCES `cotizacion` (`coti_id`),
  CONSTRAINT `cotizacion_detalle_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`producto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for detalle_venta
-- ----------------------------
 
DROP TABLE IF EXISTS `detalle_venta`;
CREATE TABLE `detalle_venta` (
  `vdetalle_id` int(11) NOT NULL AUTO_INCREMENT,
  `venta_id` int(11) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `vdetalle_cantidad` varchar(255) DEFAULT NULL,
  `vdetalle_precio` decimal(10,2) DEFAULT NULL,
  `vdetalle_estado` enum('ANULADA','VENDIDO') DEFAULT NULL,
  `vdetalle_fecha` date DEFAULT NULL,
  PRIMARY KEY (`vdetalle_id`) USING BTREE,
  KEY `venta_id` (`venta_id`) USING BTREE,
  KEY `producto_id` (`producto_id`) USING BTREE,
  CONSTRAINT `detalle_venta_ibfk_1` FOREIGN KEY (`venta_id`) REFERENCES `venta` (`venta_id`),
  CONSTRAINT `detalle_venta_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`producto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 

-- ----------------------------
-- Table structure for forma_pago
-- ----------------------------
 
DROP TABLE IF EXISTS `forma_pago`;
CREATE TABLE `forma_pago` (
  `fpago_id` int(11) NOT NULL AUTO_INCREMENT,
  `fpago_descripcion` varchar(255) DEFAULT NULL,
  `fpago_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`fpago_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table forma_pago
-- ----------------------------
 
INSERT INTO `forma_pago` (`fpago_id`,`fpago_descripcion`,`fpago_estado`) VALUES
('1','Al contado','ACTIVO'),
('2','Credito 7 dias','ACTIVO');

-- ----------------------------
-- Table structure for gastos
-- ----------------------------
 
DROP TABLE IF EXISTS `gastos`;
CREATE TABLE `gastos` (
  `gastos_id` int(11) NOT NULL AUTO_INCREMENT,
  `gastos_descripcion` varchar(255) DEFAULT NULL,
  `gastos_monto` decimal(10,2) DEFAULT NULL,
  `gastos_responsable` varchar(255) DEFAULT NULL,
  `gastos_fregistro` date DEFAULT NULL,
  `gastos_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`gastos_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table gastos
-- ----------------------------
 
INSERT INTO `gastos` (`gastos_id`,`gastos_descripcion`,`gastos_monto`,`gastos_responsable`,`gastos_fregistro`,`gastos_estado`) VALUES
('1','Pasajes recojo de equipo','6.00','Carlos','2022-02-27','ACTIVO');

-- ----------------------------
-- Table structure for kardex
-- ----------------------------
 
DROP TABLE IF EXISTS `kardex`;
CREATE TABLE `kardex` (
  `kardex_id` int(11) NOT NULL AUTO_INCREMENT,
  `kardex_fecha` date DEFAULT NULL,
  `kardex_tipo` varchar(255) DEFAULT NULL,
  `kardex_ingreso` varchar(255) DEFAULT NULL,
  `kardex_p_ingreso` decimal(10,2) DEFAULT NULL,
  `kardex_salida` varchar(255) DEFAULT NULL,
  `kardex_p_salida` decimal(10,2) DEFAULT NULL,
  `kardex_total` varchar(255) DEFAULT NULL,
  `kardex_precio_general` decimal(10,2) DEFAULT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `vdetalle_id` int(11) DEFAULT NULL,
  `producto_nombre` varchar(255) DEFAULT NULL,
  `producto_codigo` varchar(255) DEFAULT NULL,
  `venta_id` int(11) DEFAULT NULL,
  `venta_comprobante` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kardex_id`) USING BTREE,
  KEY `producto_id` (`producto_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for marca
-- ----------------------------
 
DROP TABLE IF EXISTS `marca`;
CREATE TABLE `marca` (
  `marca_id` int(11) NOT NULL AUTO_INCREMENT,
  `marca_descripcion` varchar(255) DEFAULT NULL,
  `marca_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`marca_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table marca
-- ----------------------------
 
INSERT INTO `marca` (`marca_id`,`marca_descripcion`,`marca_estado`) VALUES
('1','Lg','ACTIVO'),
('2','Sansumg','ACTIVO'),
('5','Huawei','ACTIVO'),
('7','General','ACTIVO');

-- ----------------------------
-- Table structure for motivo
-- ----------------------------
 
DROP TABLE IF EXISTS `motivo`;
CREATE TABLE `motivo` (
  `motivo_id` int(11) NOT NULL AUTO_INCREMENT,
  `motivo_descripcion` varchar(255) DEFAULT NULL,
  `motivo_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`motivo_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table motivo
-- ----------------------------
 
INSERT INTO `motivo` (`motivo_id`,`motivo_descripcion`,`motivo_estado`) VALUES
('1','Matenimiento','ACTIVO'),
('2','Garantia ','ACTIVO'),
('3','Reparacion','ACTIVO');

-- ----------------------------
-- Table structure for permiso
-- ----------------------------
 
DROP TABLE IF EXISTS `permiso`;
CREATE TABLE `permiso` (
  `idpermiso` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`idpermiso`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table permiso
-- ----------------------------
 
INSERT INTO `permiso` (`idpermiso`,`nombre`) VALUES
('1','ejemplo1'),
('2','ejemplo2'),
('3','ejemplo3'),
('4','ejemplo4'),
('5','ejemplo5'),
('6','ejemplo6'),
('7','ejemplo7');

-- ----------------------------
-- Table structure for producto
-- ----------------------------
 
DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto` (
  `producto_id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_codigo` varchar(10) NOT NULL,
  `producto_nombre` varchar(255) DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `producto_stock` varchar(255) DEFAULT NULL,
  `producto_pcompra` decimal(10,2) DEFAULT NULL,
  `producto_pventa` decimal(10,2) DEFAULT NULL,
  `producto_fregistro` date DEFAULT NULL,
  `producto_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `producto_stock_inicial` varchar(255) DEFAULT NULL,
  `producto_aumento` varchar(255) DEFAULT NULL,
  `producto_codigo_general` varchar(255) DEFAULT NULL,
  `prove_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`producto_id`) USING BTREE,
  KEY `marca_id` (`marca_id`) USING BTREE,
  KEY `categoria_id` (`categoria_id`) USING BTREE,
  KEY `prove_id` (`prove_id`) USING BTREE,
  CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`marca_id`) REFERENCES `marca` (`marca_id`),
  CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`categoria_id`),
  CONSTRAINT `producto_ibfk_3` FOREIGN KEY (`prove_id`) REFERENCES `proveedor` (`prove_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table producto
-- ----------------------------
 
INSERT INTO `producto` (`producto_id`,`producto_codigo`,`producto_nombre`,`marca_id`,`categoria_id`,`producto_stock`,`producto_pcompra`,`producto_pventa`,`producto_fregistro`,`producto_estado`,`producto_stock_inicial`,`producto_aumento`,`producto_codigo_general`,`prove_id`) VALUES
('1','P0001','Cargador Portatil','5','3','8','10.00','25.00','2022-02-21','ACTIVO','2','5','88769042455','1'),
('2','P0002','Funda para celular P30','5','1','5','12.00','25.00','2022-02-21','ACTIVO','6','4','887690','1'),
('3','P0003','Pantalla P30','5','1','2','120.00','200.00','2022-02-21','ACTIVO','3','5','9042455','1');

-- ----------------------------
-- Table structure for proveedor
-- ----------------------------
 
DROP TABLE IF EXISTS `proveedor`;
CREATE TABLE `proveedor` (
  `prove_id` int(11) NOT NULL AUTO_INCREMENT,
  `prove_ruc` varchar(255) DEFAULT NULL,
  `prove_razon` varchar(255) DEFAULT NULL,
  `prove_direccion` varchar(255) DEFAULT NULL,
  `prove_celular` varchar(255) DEFAULT NULL,
  `prove_fregistro` date DEFAULT NULL,
  `prove_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`prove_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table proveedor
-- ----------------------------
 
INSERT INTO `proveedor` (`prove_id`,`prove_ruc`,`prove_razon`,`prove_direccion`,`prove_celular`,`prove_fregistro`,`prove_estado`) VALUES
('1','203436799879','ejemplo','Sullana','987645568','2022-03-04','ACTIVO');

-- ----------------------------
-- Table structure for recepcion
-- ----------------------------
 
DROP TABLE IF EXISTS `recepcion`;
CREATE TABLE `recepcion` (
  `rece_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `rece_equipo` varchar(255) DEFAULT NULL,
  `rece_caracteristicas` varchar(255) DEFAULT NULL,
  `motivo_id` int(11) DEFAULT NULL,
  `rece_concepto` varchar(255) DEFAULT NULL,
  `rece_monto` decimal(10,2) DEFAULT NULL,
  `rece_fregistro` date DEFAULT NULL,
  `rece_estado` enum('POR ENTREGAR','POR RECOGER','ENTREGADO') DEFAULT NULL,
  `rece_estatus` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  `rece_adelanto` decimal(10,2) DEFAULT NULL,
  `rece_debe` decimal(10,2) DEFAULT NULL,
  `rece_accesorios` varchar(255) DEFAULT NULL,
  `rece_fentrega` date DEFAULT NULL,
  `marca_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`rece_id`) USING BTREE,
  KEY `cliente_id` (`cliente_id`) USING BTREE,
  KEY `motivo_id` (`motivo_id`) USING BTREE,
  KEY `marca_id` (`marca_id`) USING BTREE,
  CONSTRAINT `recepcion_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`cliente_id`),
  CONSTRAINT `recepcion_ibfk_2` FOREIGN KEY (`motivo_id`) REFERENCES `motivo` (`motivo_id`),
  CONSTRAINT `recepcion_ibfk_3` FOREIGN KEY (`marca_id`) REFERENCES `marca` (`marca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
 
-- ----------------------------
-- Records for table recepcion
-- ----------------------------
 
INSERT INTO `recepcion` (`rece_id`,`cliente_id`,`rece_equipo`,`rece_caracteristicas`,`motivo_id`,`rece_concepto`,`rece_monto`,`rece_fregistro`,`rece_estado`,`rece_estatus`,`rece_adelanto`,`rece_debe`,`rece_accesorios`,`rece_fentrega`,`marca_id`) VALUES
('1','1','celular samsung ','modelo A51 con cargador','1','pantalla rota, cambio de ping de carga','250.00','2022-02-18','POR ENTREGAR','ACTIVO','50.00','200.00','cargador','2022-02-25','1');

-- ----------------------------
-- Table structure for rol
-- ----------------------------
 
DROP TABLE IF EXISTS `rol`;
CREATE TABLE `rol` (
  `rol_id` int(11) NOT NULL AUTO_INCREMENT,
  `rol_nombre` varchar(255) DEFAULT NULL,
  `rol_fregistro` date DEFAULT NULL,
  `rol_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`rol_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table rol
-- ----------------------------
 
INSERT INTO `rol` (`rol_id`,`rol_nombre`,`rol_fregistro`,`rol_estado`) VALUES
('1','Administrador','2022-02-13','ACTIVO'),
('2','Usuario','2022-02-13','ACTIVO'),
('3','Vendedor','2022-03-02','ACTIVO');

-- ----------------------------
-- Table structure for servicio
-- ----------------------------
 
DROP TABLE IF EXISTS `servicio`;
CREATE TABLE `servicio` (
  `servicio_id` int(11) NOT NULL AUTO_INCREMENT,
  `rece_id` int(11) NOT NULL,
  `servicio_monto` decimal(10,2) NOT NULL,
  `servicio_concepto` varchar(255) DEFAULT NULL,
  `servicio_responsable` varchar(255) DEFAULT NULL,
  `servicio_comentario` varchar(255) DEFAULT NULL,
  `servicio_fregistro` date DEFAULT NULL,
  `servicio_entrega` enum('ENTREGADO') DEFAULT NULL,
  `servicio_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`servicio_id`) USING BTREE,
  KEY `rece_id` (`rece_id`) USING BTREE,
  CONSTRAINT `servicio_ibfk_1` FOREIGN KEY (`rece_id`) REFERENCES `recepcion` (`rece_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for usuario
-- ----------------------------
 
DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `usu_id` int(11) NOT NULL AUTO_INCREMENT,
  `usu_nombre` varchar(255) DEFAULT NULL,
  `usu_contrasena` varchar(255) DEFAULT NULL,
  `usu_email` varchar(255) DEFAULT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `usu_foto` varchar(255) DEFAULT NULL,
  `usu_estado` enum('ACTIVO','INACTIVO') DEFAULT NULL,
  PRIMARY KEY (`usu_id`) USING BTREE,
  KEY `rol_id` (`rol_id`) USING BTREE,
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`rol_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
-- ----------------------------
-- Records for table usuario
-- ----------------------------
 
INSERT INTO `usuario` (`usu_id`,`usu_nombre`,`usu_contrasena`,`usu_email`,`rol_id`,`usu_foto`,`usu_estado`) VALUES
('1','admin','$2y$12$C.1yXkkqqs45tHKfUJC4UuOfpRhB5aEQjQkYNVlnbIH/GXCUbeawi','Gustavo Masias ','1','controller/usuario/foto/IMG132202214564.jpg','ACTIVO'),
('2','gustavo','$2y$12$jOl2fBL6.G/c1PAogy4EyeRceX39TuoOrNC4KUi568LOoWJGj68i2','juan gustavo','3','controller/usuario/foto/default.png','ACTIVO');

-- ----------------------------
-- Table structure for usuario_permiso
-- ----------------------------
 
DROP TABLE IF EXISTS `usuario_permiso`;
CREATE TABLE `usuario_permiso` (
  `idusuario_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `usu_id` int(11) DEFAULT NULL,
  `id_permiso` int(11) DEFAULT NULL,
  PRIMARY KEY (`idusuario_permiso`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 

-- ----------------------------
-- Table structure for venta
-- ----------------------------
 
DROP TABLE IF EXISTS `venta`;
CREATE TABLE `venta` (
  `venta_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `venta_comprobante` varchar(255) DEFAULT NULL,
  `venta_serie` varchar(255) DEFAULT NULL,
  `venta_num_comprobante` varchar(255) DEFAULT NULL,
  `venta_total` decimal(10,2) DEFAULT NULL,
  `venta_impuesto` decimal(10,2) DEFAULT NULL,
  `venta_fregistro` date DEFAULT NULL,
  `venta_hora` time DEFAULT NULL,
  `venta_estado` enum('REGISTRADA','ANULADA') DEFAULT NULL,
  `compro_id` int(11) DEFAULT NULL,
  `venta_porcentaje` decimal(10,2) DEFAULT NULL,
  `usu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`venta_id`) USING BTREE,
  KEY `cliente_id` (`cliente_id`) USING BTREE,
  KEY `compro_id` (`compro_id`) USING BTREE,
  KEY `usu_id` (`usu_id`) USING BTREE,
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`cliente_id`),
  CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`compro_id`) REFERENCES `comprobante` (`compro_id`),
  CONSTRAINT `venta_ibfk_3` FOREIGN KEY (`usu_id`) REFERENCES `usuario` (`usu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
 
/*{
-- ============================================== VIEWS ================================================
-- ----------------------------
-- View structure for view_listar_recepcion
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_recepcion`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_recepcion` AS select `recepcion`.`rece_id` AS `rece_id`,`recepcion`.`cliente_id` AS `cliente_id`,`cliente`.`cliente_nombres` AS `cliente_nombres`,concat_ws(' - ',`recepcion`.`rece_equipo`,`recepcion`.`rece_concepto`) AS `motivo`,`recepcion`.`rece_caracteristicas` AS `rece_caracteristicas`,`recepcion`.`motivo_id` AS `motivo_id`,`motivo`.`motivo_descripcion` AS `motivo_descripcion`,`recepcion`.`rece_monto` AS `rece_monto`,`recepcion`.`rece_fregistro` AS `rece_fregistro`,`recepcion`.`rece_estado` AS `rece_estado`,`recepcion`.`rece_estatus` AS `rece_estatus`,`recepcion`.`rece_equipo` AS `rece_equipo`,`recepcion`.`rece_concepto` AS `rece_concepto`,`recepcion`.`rece_adelanto` AS `rece_adelanto`,`recepcion`.`rece_debe` AS `rece_debe`,`recepcion`.`rece_accesorios` AS `rece_accesorios`,`recepcion`.`rece_fentrega` AS `rece_fentrega`,`recepcion`.`marca_id` AS `marca_id`,`marca`.`marca_descripcion` AS `marca_descripcion` from (((`recepcion` join `cliente` on(`recepcion`.`cliente_id` = `cliente`.`cliente_id`)) join `motivo` on(`recepcion`.`motivo_id` = `motivo`.`motivo_id`)) join `marca` on(`recepcion`.`marca_id` = `marca`.`marca_id`));
-- ----------------------------
-- View structure for view_listar_recepcion_en_servicio
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_recepcion_en_servicio`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_recepcion_en_servicio` AS select `recepcion`.`rece_id` AS `rece_id`,`cliente`.`cliente_nombres` AS `cliente`,concat_ws(' - ',`recepcion`.`rece_equipo`,`recepcion`.`rece_concepto`) AS `concepto`,`recepcion`.`rece_monto` AS `monto`,`recepcion`.`rece_fregistro` AS `fecha`,`recepcion`.`rece_estado` AS `entrega`,`recepcion`.`rece_adelanto` AS `adelanto`,`recepcion`.`rece_debe` AS `debe`,`recepcion`.`rece_fentrega` AS `rece_fentrega` from (`recepcion` join `cliente` on(`recepcion`.`cliente_id` = `cliente`.`cliente_id`)) where `recepcion`.`rece_estado` in ('POR ENTREGAR','POR RECOGER') and `recepcion`.`rece_estatus` = 'ACTIVO';
-- ----------------------------
-- View structure for view_listar_servicio_rece
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_servicio_rece`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_servicio_rece` AS select `servicio`.`servicio_id` AS `servicio_id`,`servicio`.`rece_id` AS `rece_id`,`recepcion`.`cliente_id` AS `cliente_id`,`cliente`.`cliente_nombres` AS `cliente_nombres`,concat_ws(' - ',`recepcion`.`rece_equipo`,`recepcion`.`rece_concepto`) AS `concepto`,`recepcion`.`rece_monto` AS `rece_monto`,`recepcion`.`rece_estado` AS `rece_estado`,`servicio`.`servicio_monto` AS `servicio_monto`,`servicio`.`servicio_concepto` AS `servicio_concepto`,`servicio`.`servicio_responsable` AS `servicio_responsable`,`servicio`.`servicio_comentario` AS `servicio_comentario`,`servicio`.`servicio_entrega` AS `servicio_entrega`,`servicio`.`servicio_fregistro` AS `servicio_fregistro`,`servicio`.`servicio_estado` AS `servicio_estado` from ((`servicio` join `recepcion` on(`servicio`.`rece_id` = `recepcion`.`rece_id`)) join `cliente` on(`recepcion`.`cliente_id` = `cliente`.`cliente_id`));
-- ----------------------------
-- View structure for view_listar_usuario
-- ----------------------------
 
DROP VIEW IF EXISTS `view_listar_usuario`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_listar_usuario` AS select `usuario`.`usu_id` AS `usu_id`,`usuario`.`usu_nombre` AS `usu_nombre`,`usuario`.`usu_contrasena` AS `usu_contrasena`,`usuario`.`rol_id` AS `rol_id`,`usuario`.`usu_estado` AS `usu_estado`,`usuario`.`usu_email` AS `usu_email`,`usuario`.`usu_foto` AS `usu_foto`,`rol`.`rol_nombre` AS `rol_nombre` from (`usuario` join `rol` on(`usuario`.`rol_id` = `rol`.`rol_id`)) where `usuario`.`usu_id` <> '1';

-- ============================================== PROCEDURES ================================================
-- ----------------------------
-- Procedure structure for SP_ACTIVAR_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ACTIVAR_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ACTIVAR_COTIZACION`(IN ID INT,IN ESTADO VARCHAR(30))
BEGIN
DECLARE CANTIDAD INT;
DECLARE DETALLEID INT;

UPDATE cotizacion set
coti_estado=ESTADO
where coti_id=ID;

SET @CANTIDAD:=(SELECT COUNT(*) FROM cotizacion_detalle WHERE coti_detalle_estado= 'INACTIVO' AND coti_id=ID);
	WHILE @CANTIDAD > 0 DO

	SET @DETALLEID:=(SELECT coti_detalle_id FROM cotizacion_detalle WHERE coti_detalle_estado= 'INACTIVO' AND coti_id=ID LIMIT 1  );


	
	UPDATE cotizacion_detalle SET 
	coti_detalle_estado= ESTADO
	WHERE coti_detalle_id=@DETALLEID;
	SET @CANTIDAD:= @CANTIDAD - 1;

	END WHILE;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ANULAR_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ANULAR_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ANULAR_COTIZACION`(IN ID INT,IN ESTADO VARCHAR(30))
BEGIN
DECLARE CANTIDAD INT;
DECLARE DETALLEID INT;

UPDATE cotizacion set
coti_estado=ESTADO
where coti_id=ID;

SET @CANTIDAD:=(SELECT COUNT(*) FROM cotizacion_detalle WHERE coti_detalle_estado= 'ACTIVO' AND coti_id=ID);
	WHILE @CANTIDAD > 0 DO

	SET @DETALLEID:=(SELECT coti_detalle_id FROM cotizacion_detalle WHERE coti_detalle_estado= 'ACTIVO' AND coti_id=ID LIMIT 1  );


	
	UPDATE cotizacion_detalle SET 
	coti_detalle_estado= ESTADO
	WHERE coti_detalle_id=@DETALLEID;
	SET @CANTIDAD:= @CANTIDAD - 1;

	END WHILE;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ANULAR_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ANULAR_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ANULAR_VENTA`(IN ID INT,IN ESTADO VARCHAR(30))
BEGIN
DECLARE CANTIDAD INT;
DECLARE IDPRODUCTO INT;
DECLARE STOCKACTUAL INT;
DECLARE DETALLEID INT;

UPDATE venta set
venta_estado=ESTADO
where venta_id=ID;
SET @CANTIDAD:=(SELECT COUNT(*) FROM detalle_venta WHERE vdetalle_estado= 'VENDIDO' AND venta_id=ID);
	WHILE @CANTIDAD > 0 DO
	SET @IDPRODUCTO:=(SELECT producto_id FROM detalle_venta WHERE vdetalle_estado= 'VENDIDO' AND venta_id=ID LIMIT 1 );
	SET @DETALLEID:=(SELECT vdetalle_id FROM detalle_venta WHERE vdetalle_estado= 'VENDIDO' AND venta_id=ID LIMIT 1  );
	SET @STOCKACTUAL:=(SELECT producto_stock FROM producto WHERE producto_id=@IDPRODUCTO);
	
	UPDATE producto SET
	producto_stock=@STOCKACTUAL + (SELECT vdetalle_cantidad FROM detalle_venta WHERE vdetalle_estado= 'VENDIDO' AND venta_id=ID LIMIT 1 )
	WHERE producto_id= @IDPRODUCTO;
	UPDATE detalle_venta SET 
	vdetalle_estado= ESTADO
	WHERE vdetalle_id=@DETALLEID;
	SET @CANTIDAD:= @CANTIDAD - 1;
	

	UPDATE kardex SET 
	kardex_tipo=ESTADO,
	producto_id = @IDPRODUCTO

	WHERE vdetalle_id=@DETALLEID;
	


	END WHILE;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_AUMENTAR_STOCK
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_AUMENTAR_STOCK`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_AUMENTAR_STOCK`(IN IDPRODUCTO INT, IN CANTIDAAUMENTO VARCHAR(100),IN SUMA VARCHAR(100))
BEGIN
UPDATE producto SET 
producto_stock = SUMA,
producto_aumento = CANTIDAAUMENTO
where producto_id = IDPRODUCTO;

set @preciocompra = (select producto_pcompra from producto where producto_id =IDPRODUCTO);
set @stock = (select producto_stock from producto where producto_id =IDPRODUCTO);

insert into kardex (kardex_fecha,kardex_tipo,kardex_ingreso,kardex_p_ingreso,kardex_total,producto_id,kardex_precio_general) 
VALUES (CURDATE(),'INGRESO',CANTIDAAUMENTO,@preciocompra,@stock,IDPRODUCTO,@preciocompra);

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_BUSCAR_EQUIPO_DNI
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_BUSCAR_EQUIPO_DNI`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_BUSCAR_EQUIPO_DNI`(IN DNI INT)
SELECT
	recepcion.rece_id, 
	recepcion.cliente_id, 
		cliente.cliente_dni, 
	cliente.cliente_nombres, 
	recepcion.rece_equipo,
	recepcion.rece_concepto,
	recepcion.rece_fregistro, 
	recepcion.rece_estado
FROM
	recepcion
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id
		where cliente.cliente_dni = DNI 
		ORDER BY recepcion.rece_fregistro DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ELIMINAR_MARCA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ELIMINAR_MARCA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ELIMINAR_MARCA`(IN ID INT)
DELETE FROM marca WHERE marca_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ELIMINAR_ROL_ESTADO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ELIMINAR_ROL_ESTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ELIMINAR_ROL_ESTADO`(IN ID INT,IN ESTADO VARCHAR(30))
UPDATE rol set
rol_estado=ESTADO
where rol_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ELIMINAR_SERVICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ELIMINAR_SERVICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ELIMINAR_SERVICIO`(IN ID INT)
DELETE  FROM servicio 
where servicio_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_ELIMINAR_USUARIO_ESTADO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_ELIMINAR_USUARIO_ESTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_ELIMINAR_USUARIO_ESTADO`(IN ID INT,IN ESTADO VARCHAR(10))
UPDATE usuario set
usu_estado=ESTADO
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_GRAFICO_SERVICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_GRAFICO_SERVICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_GRAFICO_SERVICIO`(IN FINICIO DATE, IN FFIN DATE)
SELECT
COUNT(motivo.motivo_descripcion ) as cantidad,	
CONCAT_WS(' - ',motivo.motivo_descripcion,recepcion.rece_equipo) as Tipos 
FROM
	recepcion
	INNER JOIN
	servicio
	ON 
		recepcion.rece_id = servicio.rece_id
	INNER JOIN
	motivo
	ON 
		recepcion.motivo_id = motivo.motivo_id
			WHERE servicio.servicio_fregistro BETWEEN FINICIO AND FFIN
	GROUP BY recepcion.motivo_id ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_INICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_INICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_INICIO`()
BEGIN
	DECLARE VENTA INT;
	DECLARE SERVICIO INT;
	SELECT COUNT(*) INTO VENTA FROM venta WHERE venta_estado='REGISTRADA';
	SELECT COUNT(*) INTO SERVICIO FROM servicio WHERE servicio_estado='ACTIVO';
	
	SELECT VENTA, SERVICIO;


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_KARDEX_COD_PRODUCTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_KARDEX_COD_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_KARDEX_COD_PRODUCTO`(IN CODPRODUCTO INT)
SELECT
	kardex.kardex_id,
	CONCAT_WS('  ',kardex.producto_codigo,kardex.producto_nombre	) as producto, 
	kardex.kardex_fecha as fecha, 
	kardex.kardex_tipo as tipo, 
	kardex.kardex_ingreso as ingreso, 
	kardex.kardex_p_ingreso as precio_ingreso, 
	(kardex.kardex_ingreso * kardex.kardex_p_ingreso ) as total_ingreso,
	kardex.kardex_salida as salida, 
	kardex.kardex_p_salida as precio_salida, 
	(kardex.kardex_salida * kardex.kardex_p_salida ) as total_salida,
	kardex.kardex_total as total_actual, 
	 kardex_precio_general  as precio_total, 
	(kardex.kardex_total * kardex_precio_general  ) as total_total,
	kardex.producto_id, 
	 
	kardex.venta_comprobante
FROM
	kardex
	where producto_id = CODPRODUCTO and kardex_tipo in ('INICIAL','INGRESO','SALIDA') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_KARDEX_NOMBRE_CODIGO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_KARDEX_NOMBRE_CODIGO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_KARDEX_NOMBRE_CODIGO`(IN NOMBRE VARCHAR(255))
SELECT
	kardex.kardex_id, 
	kardex.producto_id, 
  kardex.producto_nombre,
	kardex.kardex_p_ingreso, 
	SUM(kardex_ingreso) as ingresos,
	sum(kardex_salida) as salidas,
	(SUM(kardex_ingreso) - sum(kardex_salida) ) as saldo
FROM
	kardex
	where  kardex.producto_nombre like  CONCAT('%',NOMBRE,'%') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ANIO_GASTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ANIO_GASTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ANIO_GASTO`()
SELECT YEAR(gastos_fregistro) as anio FROM gastos
where gastos_estado='ACTIVO' 
GROUP BY YEAR(gastos_fregistro) DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ANIO_SERVICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ANIO_SERVICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ANIO_SERVICIO`()
SELECT YEAR(servicio_fregistro) as anio FROM servicio
GROUP BY YEAR(servicio_fregistro) DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CATEGORIA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CATEGORIA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CATEGORIA`()
SELECT
	categoria.categoria_id, 
	categoria.categoria_descripcion, 
	categoria.categoria_estado
FROM
	categoria
	WHERE categoria.categoria_estado  = 'ACTIVO' OR categoria.categoria_estado  = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CLIENTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CLIENTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CLIENTE`()
SELECT
	cliente.cliente_id, 
	cliente.cliente_nombres, 
	cliente.cliente_celular, 
	cliente.cliente_dni, 
	cliente.cliente_estado,
	cliente.cliente_direccion
FROM
	cliente
		WHERE cliente.cliente_estado ='ACTIVO' OR cliente.cliente_estado = 'INACTIVO'
		ORDER BY cliente_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_CLIENTE_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_CLIENTE_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_CLIENTE_VENTA`()
SELECT
	cliente.cliente_id, 
	cliente.cliente_nombres, 
	cliente.cliente_dni
FROM
	cliente
		WHERE cliente.cliente_estado ='ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_COMPROBANTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_COMPROBANTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_COMPROBANTE`()
SELECT
	comprobante.compro_id, 
	comprobante.compro_tipo, 
	comprobante.compro_serie, 
	comprobante.compro_numero, 
	comprobante.compro_estado
FROM
	comprobante
		WHERE comprobante.compro_estado = 'ACTIVO' OR comprobante.compro_estado  = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_COTIZACION`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	cotizacion.coti_id, 
	cotizacion.prove_id, 
	proveedor.prove_razon, 
	CONCAT_WS(' - ',cotizacion.coti_comprobante, cotizacion.coti_num_comprobante) AS cotizacion, 
	cotizacion.coti_total, 
	cotizacion.coti_fregistro, 
	cotizacion.usu_id, 
	usuario.usu_nombre, 
	cotizacion.coti_estado
FROM
	cotizacion
	INNER JOIN
	proveedor
	ON 
		cotizacion.prove_id = proveedor.prove_id
	INNER JOIN
	usuario
	ON 
		cotizacion.usu_id = usuario.usu_id
		WHERE cotizacion.coti_fregistro BETWEEN FINICIO AND FFIN
		ORDER BY coti_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_DATOS_WIDGET
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_DATOS_WIDGET`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_DATOS_WIDGET`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	(select count(*) from venta where venta_estado='REGISTRADA' and venta_fregistro BETWEEN FINICIO AND FFIN)as ventas,
	(SELECT IFNULL(SUM(venta.venta_total),0) FROM venta WHERE venta_fregistro BETWEEN FINICIO AND FFIN) as total_venta,
	(SELECT COUNT(*) FROM servicio WHERE servicio_fregistro BETWEEN FINICIO AND FFIN ) as servicio,
	(select IFNULL(SUM(servicio_monto),0) from servicio where servicio_fregistro BETWEEN FINICIO AND FFIN ) as total_servicio,
	(SELECT COUNT(*) FROM gastos where gastos_fregistro BETWEEN FINICIO AND FFIN) as gastos,
	(select IFNULL(SUM(gastos_monto),0) from gastos where gastos_fregistro BETWEEN FINICIO AND FFIN ) as total_gastos,
	(SELECT COUNT(*) FROM producto where producto_fregistro BETWEEN FINICIO AND FFIN) as productos
FROM
	venta ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_DATOS_WIDGET2
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_DATOS_WIDGET2`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_DATOS_WIDGET2`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	COUNT(*),
	(SELECT COUNT(*) FROM servicio where servicio.servicio_fregistro BETWEEN FINICIO AND FFIN ) as servicio
FROM
	VENTA
	WHERE venta.venta_fregistro BETWEEN FINICIO AND FFIN ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_EMPRESA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_EMPRESA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_EMPRESA`()
SELECT
	configuracion.confi_id, 
	configuracion.confi_razon_social, 
	configuracion.confi_ruc, 
	configuracion.confi_nombre_representante, 
	configuracion.confi_direccion, 
	configuracion.confi_celular, 
	configuracion.confi_telefono, 
	configuracion.confi_correo, 
	configuracion.config_foto, 
	configuracion.confi_estado,
	configuracion.confi_url,
	configuracion.confi_cnta01,
	configuracion.confi_nro_cuenta01,
	configuracion.confi_cnta02,
	configuracion.confi_nro_cuenta02
FROM
	configuracion ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_FORMA_PAGO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_FORMA_PAGO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_FORMA_PAGO`()
SELECT
	forma_pago.fpago_id, 
	forma_pago.fpago_descripcion, 
	forma_pago.fpago_estado
FROM
	forma_pago ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_GASTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_GASTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_GASTO`()
SELECT
	gastos.gastos_id, 
	gastos.gastos_descripcion, 
	gastos.gastos_monto, 
	gastos.gastos_responsable, 
	gastos.gastos_fregistro, 
	gastos.gastos_estado
FROM
	gastos
	WHERE gastos.gastos_estado ='ACTIVO' OR gastos.gastos_estado = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_MARCA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_MARCA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_MARCA`()
SELECT
	marca.marca_id, 
	marca.marca_descripcion, 
	marca.marca_estado
FROM
	marca
	WHERE marca.marca_estado ='ACTIVO' OR marca.marca_estado = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_MOTIVO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_MOTIVO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_MOTIVO`()
SELECT
	motivo.motivo_id, 
	motivo.motivo_descripcion, 
	motivo.motivo_estado
FROM
	motivo
		WHERE motivo.motivo_estado='ACTIVO' OR motivo.motivo_estado = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_NOTIFICACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_NOTIFICACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_NOTIFICACION`()
SELECT
	cliente.cliente_nombres, 
	recepcion.rece_estado, 
	recepcion.rece_fregistro,
	recepcion.rece_equipo
FROM
	recepcion
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id
			WHERE recepcion.rece_estado in ('POR ENTREGAR','POR RECOGER') AND recepcion.rece_estatus = 'ACTIVO'
			ORDER BY recepcion.rece_fregistro DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_NUM_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_NUM_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_NUM_COTIZACION`()
SELECT compro_numero FROM comprobante WHERE compro_tipo like '%coti%' and comprobante.compro_estado= 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_PRODUCTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_PRODUCTO`()
SELECT
	producto.producto_id, 
	producto.producto_nombre, 
	producto.producto_codigo, 
	producto.marca_id, 
	marca.marca_descripcion, 
	producto.categoria_id, 
	categoria.categoria_descripcion, 
	producto.producto_stock, 
	producto.producto_pcompra, 
	producto.producto_pventa, 
	producto.producto_estado, 
	producto.producto_codigo_general, 
	producto.prove_id, 
	proveedor.prove_razon
FROM
	producto
	INNER JOIN
	categoria
	ON 
		producto.categoria_id = categoria.categoria_id
	INNER JOIN
	marca
	ON 
		producto.marca_id = marca.marca_id
	INNER JOIN
	proveedor
	ON 
		producto.prove_id = proveedor.prove_id

		where producto.producto_estado = 'ACTIVO' or producto.producto_estado = 'INACTIVO'
		ORDER BY producto_id  DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_PRODUCTOS_MAS_VENDIDOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_PRODUCTOS_MAS_VENDIDOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_PRODUCTOS_MAS_VENDIDOS`()
SELECT 
	detalle_venta.vdetalle_id, 
	detalle_venta.producto_id, 
	CONCAT_WS(' - ',producto.producto_codigo, producto.producto_nombre) as Producto, 
	sum(vdetalle_cantidad) as cantidad
FROM
	detalle_venta
	INNER JOIN
	producto
	ON 
		detalle_venta.producto_id = producto.producto_id
		GROUP BY producto.producto_id 
		ORDER BY sum(vdetalle_cantidad) DESC
		LIMIT 7 ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_PRODUCTO_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_PRODUCTO_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_PRODUCTO_VENTA`()
SELECT
	producto.producto_id, 
	producto.producto_nombre, 
	producto.marca_id, 
	marca.marca_descripcion, 
	producto.categoria_id, 
	categoria.categoria_descripcion, 
 
	producto.producto_stock, 
	producto.producto_pcompra, 
	producto.producto_pventa, 
	producto.producto_estado
FROM
	producto
	INNER JOIN
	categoria
	ON 
		producto.categoria_id = categoria.categoria_id
	INNER JOIN
	marca
	ON 
		producto.marca_id = marca.marca_id
		where producto.producto_estado = 'ACTIVO' 
		ORDER BY producto_id  DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_PROVEEDOR
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_PROVEEDOR`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_PROVEEDOR`()
SELECT
	proveedor.prove_id, 
	proveedor.prove_ruc, 
	proveedor.prove_razon, 
	proveedor.prove_direccion, 
	proveedor.prove_celular, 
	proveedor.prove_fregistro, 
	proveedor.prove_estado
	
FROM
	proveedor
	WHERE proveedor.prove_estado ='ACTIVO' OR proveedor.prove_estado = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_ROL`()
SELECT
	rol.rol_id, 
	rol.rol_nombre, 
	rol.rol_fregistro, 
	rol.rol_estado
FROM
	rol
	WHERE rol.rol_estado ='ACTIVO' OR rol.rol_estado = 'INACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ANIO_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ANIO_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ANIO_VENTA`()
SELECT YEAR(venta_fregistro) as anio FROM venta
where venta_estado='REGISTRADA' 
GROUP BY YEAR(venta_fregistro) DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_CATEGORIA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_CATEGORIA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_CATEGORIA`()
SELECT * FROM categoria WHERE categoria.categoria_estado = 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_CLIENTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_CLIENTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_CLIENTE`()
SELECT * FROM cliente WHERE cliente_estado= 'ACTIVO' 	ORDER BY cliente_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_COMPROBANTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_COMPROBANTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_COMPROBANTE`()
SELECT * FROM comprobante WHERE comprobante.compro_estado= 'ACTIVO' and compro_tipo not in ('COTIZACION') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_COMP_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_COMP_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_COMP_COTIZACION`()
SELECT * FROM comprobante WHERE compro_tipo like '%coti%' and comprobante.compro_estado= 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_FOR_PAGO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_FOR_PAGO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_FOR_PAGO`()
SELECT
	forma_pago.fpago_id, 
	forma_pago.fpago_descripcion
FROM
	forma_pago
	WHERE fpago_estado = 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_MARCA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_MARCA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_MARCA`()
SELECT * FROM marca WHERE marca.marca_estado= 'ACTIVO'
ORDER BY marca.marca_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_MOTIVO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_MOTIVO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_MOTIVO`()
SELECT * FROM motivo WHERE motivo_estado= 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_PRODUCTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_PRODUCTO`()
SELECT producto_id, CONCAT_WS(' - ',producto_codigo, producto_nombre) as nombre  FROM producto where producto_estado = 'ACTIVO'
ORDER BY producto_id desc ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_PRODUCTO_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_PRODUCTO_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_PRODUCTO_VENTA`()
SELECT   producto_id, 
producto_nombre as nombre,
producto_stock as stock, 
producto_pventa as precio_venta 
FROM producto 
where producto_estado = 'ACTIVO'
ORDER BY producto_id desc ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_PROVEEDOR
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_PROVEEDOR`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_PROVEEDOR`()
SELECT * FROM proveedor WHERE proveedor.prove_estado= 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SELECT_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SELECT_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SELECT_ROL`()
SELECT * FROM ROL WHERE rol_estado = 'ACTIVO' ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_SERVICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_SERVICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_SERVICIO`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	servicio.servicio_id, 
	servicio.rece_id, 
	recepcion.cliente_id, 
	cliente.cliente_nombres, 
	CONCAT_WS(' - ',recepcion.rece_equipo,recepcion.rece_concepto) as concepto, 
	recepcion.rece_monto, 
	recepcion.rece_estado, 
	servicio.servicio_monto, 
	servicio.servicio_concepto, 
	servicio.servicio_responsable, 
	servicio.servicio_comentario, 
	servicio.servicio_entrega,
	servicio.servicio_fregistro,
	servicio.servicio_estado,
	cliente.cliente_dni 
FROM
	servicio
	INNER JOIN
	recepcion
	ON 
		servicio.rece_id = recepcion.rece_id
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id 
		WHERE servicio.servicio_fregistro BETWEEN FINICIO AND FFIN ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_USUARIO`()
SELECT
	usuario.usu_id, 
	usuario.usu_nombre, 
	usuario.usu_contrasena, 
	usuario.rol_id, 
	usuario.usu_estado, 
	usuario.usu_email, 
	usuario.usu_foto, 
	rol.rol_nombre
FROM
	usuario
	INNER JOIN
	rol
	ON 
		usuario.rol_id = rol.rol_id
	WHERE  usuario.usu_id not in ('1') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_LISTAR_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_LISTAR_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_LISTAR_VENTA`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	venta.venta_id, 
	cliente.cliente_nombres, 
	venta.venta_comprobante, 
	CONCAT_WS(' - ',venta.venta_serie,venta.venta_num_comprobante) AS comprobante, 
	venta.venta_total, 
	venta.venta_fregistro, 
	venta.venta_estado, 
	venta.compro_id, 
	venta.usu_id, 
	usuario.usu_nombre
FROM
	venta
	INNER JOIN
	cliente
	ON 
		venta.cliente_id = cliente.cliente_id
	INNER JOIN
	comprobante
	ON 
		venta.compro_id = comprobante.compro_id
	INNER JOIN
	usuario
	ON 
		venta.usu_id = usuario.usu_id
		WHERE venta.venta_fregistro BETWEEN FINICIO AND FFIN
		ORDER BY venta_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_CATEGORIA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_CATEGORIA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_CATEGORIA`(IN ID INT,IN CATEGORIA VARCHAR(255),IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE CATEGORIAACTUAL VARCHAR(25);
SET @CATEGORIAACTUAL:=(SELECT categoria_descripcion from categoria where categoria_id=ID);
IF @CATEGORIAACTUAL = CATEGORIA THEN
	UPDATE categoria set
	categoria_descripcion=CATEGORIA,
	categoria_estado=ESTADO
	where categoria_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM  categoria where categoria_descripcion=CATEGORIA);
	if @CANTIDAD = 0 THEN
		UPDATE categoria set
		categoria_descripcion=CATEGORIA,
		categoria_estado=ESTADO
		where categoria_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_CLAVE_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_CLAVE_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_CLAVE_USUARIO`(IN ID INT,IN CONTRA VARCHAR(255))
UPDATE usuario set
usu_contrasena=CONTRA
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_CLIENTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_CLIENTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_CLIENTE`(IN ID INT, IN NOMBRE VARCHAR(100), IN DNI VARCHAR(20),IN CELULAR VARCHAR(20), IN ESTADO VARCHAR(100),IN DIRECCION VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
DECLARE CLIENTEACTUAL VARCHAR(25);
SET @CLIENTEACTUAL:=(SELECT cliente_dni from cliente where cliente_id=ID);
IF @CLIENTEACTUAL = DNI THEN
	UPDATE cliente set
	cliente_nombres=NOMBRE,
	cliente_celular=CELULAR,
	cliente_dni=DNI,
	cliente_estado=ESTADO,
	cliente_direccion=DIRECCION
	where cliente_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM cliente where cliente_dni=DNI);
	if @CANTIDAD = 0 THEN
		UPDATE cliente set
		cliente_nombres=NOMBRE,
		cliente_celular=CELULAR,
		cliente_dni=DNI,
		cliente_estado=ESTADO,
		cliente_direccion=DIRECCION
		where cliente_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_COMPROBANTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_COMPROBANTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_COMPROBANTE`(IN ID INT,IN TIPO VARCHAR(100),IN SERIE VARCHAR(100),IN NUMERO VARCHAR(100), IN ESTADO VARCHAR(100))
UPDATE comprobante SET
compro_tipo = TIPO,
compro_serie = SERIE,
compro_numero = NUMERO,
compro_estado = ESTADO
WHERE compro_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_EMPRESA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_EMPRESA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_EMPRESA`(IN ID INT, IN RAZON VARCHAR(255), IN RUC VARCHAR(255), IN REPRE VARCHAR(255), IN DIRECCION VARCHAR(255), IN CELULAR VARCHAR(255), IN TELEFONO VARCHAR(255), IN CORREO VARCHAR(255), IN ESTADO VARCHAR(255), IN URL VARCHAR(255), IN CUENTA01 VARCHAR(100),IN NRO_CUENTA01 VARCHAR(100),IN CUENTA02 VARCHAR(100),IN NRO_CUENTA02 VARCHAR(100))
UPDATE configuracion SET
confi_razon_social = RAZON,
confi_ruc = RUC,
confi_nombre_representante = REPRE,
confi_direccion = DIRECCION,
confi_celular = CELULAR,
confi_telefono = TELEFONO,
confi_correo = CORREO,
confi_estado = ESTADO,
confi_url = URL,
confi_cnta01 = CUENTA01,
confi_nro_cuenta01 = NRO_CUENTA01,
confi_cnta02 =  CUENTA02,
confi_nro_cuenta02 = NRO_CUENTA02
WHERE confi_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_FORMA_PAGO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_FORMA_PAGO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_FORMA_PAGO`(IN ID INT,IN FORMAPAGO VARCHAR(25),IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE FORMAPACTUAL VARCHAR(25);
SET @FORMAPACTUAL:=(SELECT fpago_descripcion from forma_pago where fpago_id=ID);
IF @FORMAPACTUAL = FORMAPAGO THEN
	UPDATE forma_pago set
	fpago_descripcion=FORMAPAGO,
	fpago_estado=ESTADO
	where fpago_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM forma_pago where fpago_descripcion=FORMAPAGO);
	if @CANTIDAD = 0 THEN
			UPDATE forma_pago set
			fpago_descripcion=FORMAPAGO,
			fpago_estado=ESTADO
			where fpago_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_FOTO_EMPRESA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_FOTO_EMPRESA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_FOTO_EMPRESA`(IN ID INT,IN RUTA VARCHAR(255))
UPDATE configuracion SET
config_foto = RUTA
WHERE confi_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_FOTO_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_FOTO_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_FOTO_USUARIO`(IN ID INT,IN RUTA VARCHAR(255))
UPDATE usuario set
usu_foto=RUTA
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_GASTOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_GASTOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_GASTOS`(IN ID INT,IN GASTO VARCHAR(255),IN NOMTO INT,IN RESPONSABLE VARCHAR(255), IN ESTADO VARCHAR(100))
BEGIN
DECLARE CANTIDAD INT;
DECLARE GASTOACTUAL VARCHAR(25);
SET @GASTOACTUAL:=(SELECT gastos_descripcion from gastos where gastos_id=ID);
IF @GASTOACTUAL = GASTO THEN
	UPDATE gastos set
	gastos_descripcion=GASTO,
	gastos_monto=NOMTO,
	gastos_responsable=RESPONSABLE,
	gastos_estado=ESTADO
	where gastos_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM gastos where gastos_descripcion=GASTO);
	if @CANTIDAD = 0 THEN
		UPDATE gastos set
		gastos_descripcion=GASTO,
		gastos_monto=NOMTO,
		gastos_responsable=RESPONSABLE,
		gastos_estado=ESTADO
		where gastos_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_MARCA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_MARCA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_MARCA`(IN ID INT,IN MARCA VARCHAR(25),IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE MARCAACTUAL VARCHAR(25);
SET @MARCAACTUAL:=(SELECT marca_descripcion from marca where marca_id=ID);
IF @MARCAACTUAL = MARCA THEN
	UPDATE marca set
	marca_descripcion=MARCA,
	marca_estado=ESTADO
	where marca_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM marca where marca_descripcion=MARCA);
	if @CANTIDAD = 0 THEN
		UPDATE marca set
		marca_descripcion=MARCA,
		marca_estado=ESTADO
		where marca_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_MOTIVO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_MOTIVO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_MOTIVO`(IN ID INT,IN MOTIVO VARCHAR(25),IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE MOTIVOACTUAL VARCHAR(25);
SET @MOTIVOACTUAL:=(SELECT motivo_descripcion from motivo where motivo_id=ID);
IF @MOTIVOACTUAL = MOTIVO THEN
	UPDATE motivo set
	motivo_descripcion=MOTIVO,
	motivo_estado=ESTADO
	where motivo_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM motivo where motivo_descripcion=MOTIVO);
	if @CANTIDAD = 0 THEN
		UPDATE motivo set
	motivo_descripcion=MOTIVO,
	motivo_estado=ESTADO
	where motivo_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_PRODUCTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_PRODUCTO`(IN ID INT ,IN PRODUCTO VARCHAR(100),IN IDMARCA INT, IN IDCATEGORIA INT, IN PCOMPRA INT, IN PVENTA INT, IN ESTADO VARCHAR(100),IN COD_GENERAL VARCHAR(255))
BEGIN
DECLARE PRODUCTOACTUAL VARCHAR(100);
DECLARE CANTIDAD INT;
SET @PRODUCTOACTUAL:=(SELECT producto_nombre from producto where producto_id=ID and producto_nombre= PRODUCTO);
if @PRODUCTOACTUAL = PRODUCTO THEN
	UPDATE producto set
	producto_nombre=PRODUCTO,
	marca_id=IDMARCA,
	categoria_id=IDCATEGORIA,
	producto_pcompra=PCOMPRA,
	producto_pventa=PVENTA,
	producto_estado=ESTADO,
	producto_codigo_general= COD_GENERAL
	WHERE producto_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) from producto where producto_nombre= PRODUCTO);
	IF @CANTIDAD = 0 THEN
		UPDATE producto set
	producto_nombre=PRODUCTO,
	marca_id=IDMARCA,
	categoria_id=IDCATEGORIA,
	producto_pcompra=PCOMPRA,
	producto_pventa=PVENTA,
	producto_estado=ESTADO,
  producto_codigo_general= COD_GENERAL
	WHERE producto_id=ID;
			SELECT 1;
	ELSE
			SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_PROVEEDOR
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_PROVEEDOR`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_PROVEEDOR`(IN ID INT,IN RUC VARCHAR(30),IN RAZON VARCHAR(255),IN DIRECCION VARCHAR(255),IN CELULAR VARCHAR(20), IN ESTADO VARCHAR(100))
BEGIN
DECLARE CANTIDAD INT;
DECLARE PROVEACTUAL VARCHAR(25);
SET @PROVEACTUAL:=(SELECT prove_ruc from proveedor where prove_id=ID);
IF @PROVEACTUAL = RUC THEN
	UPDATE proveedor set
	prove_ruc=RUC,
	prove_razon=RAZON,
	prove_direccion=DIRECCION,
	prove_celular=CELULAR,
	prove_estado=ESTADO
	where prove_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM proveedor where prove_ruc=RUC);
	if @CANTIDAD = 0 THEN
		UPDATE proveedor set
		prove_ruc=RUC,
		prove_razon=RAZON,
		prove_direccion=DIRECCION,
		prove_celular=CELULAR,
		prove_estado=ESTADO
		where prove_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_RECEPCION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_RECEPCION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_RECEPCION`(IN IDRECE INT ,IN IDCLIENTE INT, IN EQUIPO VARCHAR(255), IN CARACTERISTICAS VARCHAR(255), IN IDMOTIVO INT,IN CONCEPTO VARCHAR(255),IN MONTO INT,IN ESTADO VARCHAR(100),IN ADELANTO DECIMAL (10,2) ,IN DEBE DECIMAL (10,2),IN ACCESORIOS VARCHAR(255), IN FENTREGA DATE,IN MARCAID INT, IN RECOGER VARCHAR(50))
UPDATE recepcion set
	cliente_id=IDCLIENTE,
	rece_equipo=EQUIPO,
	rece_caracteristicas=CARACTERISTICAS,
	motivo_id=IDMOTIVO,
	rece_concepto=CONCEPTO,
	rece_monto=MONTO,
	rece_estatus=ESTADO,
	rece_adelanto= ADELANTO,
	rece_debe= DEBE,
	rece_accesorios = ACCESORIOS,
	rece_fentrega = FENTREGA,
	marca_id = MARCAID,
	rece_estado = RECOGER
	WHERE rece_id=IDRECE ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_ROL`(IN ID INT,IN ROL VARCHAR(25),IN ESTADO VARCHAR(10))
BEGIN
DECLARE CANTIDAD INT;
DECLARE ROLACTUAL VARCHAR(25);
SET @ROLACTUAL:=(SELECT rol_nombre from rol where rol_id=ID);
IF @ROLACTUAL = ROL THEN
	UPDATE rol set
	rol_nombre=ROL,
	rol_estado=ESTADO
	where rol_id=ID;
	SELECT 1;
ELSE
	SET @CANTIDAD:=(SELECT COUNT(*) FROM rol where rol_nombre=ROL);
	if @CANTIDAD = 0 THEN
		UPDATE rol set
		rol_nombre=ROL,
		rol_estado=ESTADO
		where rol_id=ID;
		SELECT 1;
	ELSE
		SELECT 2;
	END IF;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO`(IN ID INT, IN USUARIO VARCHAR(20), IN CORREO VARCHAR(255), IN ROL INT)
UPDATE usuario SET
usu_email = CORREO,
usu_nombre = USUARIO,
rol_id = ROL
WHERE usu_id = ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_MODIFICAR_USUARIO_ESTADO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_MODIFICAR_USUARIO_ESTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_MODIFICAR_USUARIO_ESTADO`(IN ID INT,IN ESTADO VARCHAR(10))
UPDATE usuario set
usu_estado=ESTADO
where usu_id=ID ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_CATEGORIA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_CATEGORIA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_CATEGORIA`(IN CATEGORIA VARCHAR(25))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM categoria where categoria_descripcion=CATEGORIA);
if @CANTIDAD = 0 THEN
INSERT into categoria(categoria_descripcion,categoria_estado)values(CATEGORIA,'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_CLIENTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_CLIENTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_CLIENTE`(IN NOMBRE VARCHAR(100),IN DNI VARCHAR(20),IN CELULAR VARCHAR(20), IN DIRECCION VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM cliente where cliente_dni=DNI );
IF @CANTIDAD = 0 THEN
	INSERT INTO cliente(cliente_nombres,cliente_celular,cliente_dni,cliente_fregistro,cliente_estado,cliente_direccion) VALUES(NOMBRE,CELULAR,DNI,CURDATE(),'ACTIVO',DIRECCION);
	SELECT 1;
ELSE
	SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_COMPROBANTE
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_COMPROBANTE`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_COMPROBANTE`(IN TIPO VARCHAR(100),IN SERIE VARCHAR(100),IN NUMERO VARCHAR(100))
INSERT into comprobante(compro_tipo,compro_serie,compro_numero,compro_estado)values(TIPO, SERIE,NUMERO,'ACTIVO') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_COTIZACION`(IN IDPROVEEDOR INT, IN COMPROBANTE VARCHAR(255), IN SERIE VARCHAR(255), IN IMPUESTO DECIMAL(10,2),IN TOTAL DECIMAL(10,2),IN IDCOMPROBANTE INT,IN PORCENTAJE DECIMAL(10,2),IN IDUSUARIO INT, IN ATIENDE VARCHAR(255), IN DIASVAL VARCHAR(10), IN FORMAPAGO INT)
BEGIN

DECLARE COMPRO INT;
DECLARE CORRELATIVO INT;
SET @COMPRO:=(SELECT compro_numero FROM comprobante WHERE compro_id=IDCOMPROBANTE);
SET @CORRELATIVO:=(SELECT COUNT(*) FROM comprobante WHERE compro_numero=@COMPRO);		

INSERT INTO cotizacion(prove_id,coti_comprobante,coti_serie,coti_num_comprobante,coti_fregistro,coti_impuesto,coti_total,coti_estado,compro_id,coti_porcentaje,usu_id,coti_hora,coti_atiende,coti_dias,fpago_id) VALUES (IDPROVEEDOR,COMPROBANTE,SERIE,@COMPRO,CURDATE(),IMPUESTO,TOTAL,'ACTIVO',IDCOMPROBANTE,PORCENTAJE,IDUSUARIO,CURRENT_TIME(),ATIENDE,DIASVAL,FORMAPAGO);
SELECT LAST_INSERT_ID();
		




UPDATE comprobante SET 
		compro_numero=LPAD( @COMPRO + 1, 6, '0')
		where compro_id=IDCOMPROBANTE;





END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_DETALLE_COTIZACION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_DETALLE_COTIZACION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_DETALLE_COTIZACION`(IN IDCOTI INT, IN PRODUCTO INT, IN CANTIDAD DECIMAL(10,2), IN PRECIO DECIMAL(10,2))
BEGIN
INSERT INTO cotizacion_detalle(coti_id, producto_id,coti_detalle_cantidad,coti_detalle_precio,coti_detalle_estado,coti_detalle_fecha)VALUES(IDCOTI,PRODUCTO,CANTIDAD,PRECIO,'ACTIVO',CURDATE());


END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_DETALLE_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_DETALLE_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_DETALLE_VENTA`(IN IDVENTA INT, IN PRODUCTO INT, IN CANTIDAD DECIMAL(10,2), IN PRECIO DECIMAL(10,2))
BEGIN
INSERT INTO detalle_venta(venta_id, producto_id,vdetalle_cantidad,vdetalle_precio,vdetalle_estado,vdetalle_fecha)VALUES(IDVENTA,PRODUCTO,CANTIDAD,PRECIO,'VENDIDO',CURDATE());

set @preciocompra = (select producto_pcompra from producto where producto_id =PRODUCTO);
set @stock = (select producto_stock from producto where producto_id =PRODUCTO);

set @COMPROBANTE = (select CONCAT_WS('-',venta_comprobante,venta_serie,venta_num_comprobante) as COMPROBANTE from venta where venta_id=IDVENTA);

set @ID_DETALLE_VENTA = LAST_INSERT_ID();

INSERT INTO kardex(kardex_fecha,kardex_tipo,kardex_salida,kardex_p_salida,kardex_total,producto_id,venta_id,vdetalle_id,venta_comprobante,kardex_precio_general) 
VALUES(CURDATE(),'SALIDA',CANTIDAD,@preciocompra,@stock,PRODUCTO,IDVENTA,@ID_DETALLE_VENTA,@COMPROBANTE,@preciocompra );
		END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_EMPRESA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_EMPRESA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_EMPRESA`(IN RAZON VARCHAR(255), IN RUC VARCHAR(255), IN REPRE VARCHAR(255), IN DIRECCION VARCHAR(255), IN CELULAR VARCHAR(255), IN TELEFONO VARCHAR(255), IN CORREO VARCHAR(255), IN RUTA VARCHAR(255), in URL VARCHAR(255), IN CUENTA01 VARCHAR(100),IN NRO_CUENTA01 VARCHAR(100),IN CUENTA02 VARCHAR(100),IN NRO_CUENTA02 VARCHAR(100))
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM configuracion WHERE confi_ruc = BINARY RUC);
IF @CANT = 0 THEN
	INSERT INTO configuracion(confi_razon_social,confi_ruc,confi_nombre_representante,confi_direccion,confi_celular,confi_telefono,confi_correo,config_foto,confi_estado,confi_url,confi_cnta01,confi_nro_cuenta01,confi_cnta02,confi_nro_cuenta02)
	VALUES (RAZON,RUC,REPRE,DIRECCION,CELULAR,TELEFONO,CORREO,RUTA,'ACTIVO',URL,CUENTA01,NRO_CUENTA01,CUENTA02,NRO_CUENTA02);
SELECT 1;
ELSE
	SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_FORMA_PAGO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_FORMA_PAGO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_FORMA_PAGO`(IN FORMAPAGO VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM forma_pago where fpago_descripcion=FORMAPAGO);
if @CANTIDAD = 0 THEN
INSERT into forma_pago(fpago_descripcion,fpago_estado)values(FORMAPAGO,'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_GASTOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_GASTOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_GASTOS`(IN GASTO VARCHAR(255),IN NOMTO INT,IN RESPONSABLE VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM gastos where gastos_descripcion=GASTO);
if @CANTIDAD = 0 THEN
INSERT into gastos(gastos_descripcion,gastos_monto,gastos_responsable,gastos_fregistro,gastos_estado)values(GASTO,NOMTO,RESPONSABLE,CURDATE(),'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_MARCA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_MARCA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_MARCA`(IN MARCA VARCHAR(25))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM marca where marca_descripcion=MARCA);
if @CANTIDAD = 0 THEN
INSERT into marca(marca_descripcion,marca_estado)values(MARCA,'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_MOTIVO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_MOTIVO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_MOTIVO`(IN MOTIVO VARCHAR(255))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM motivo where motivo_descripcion=MOTIVO);
if @CANTIDAD = 0 THEN
INSERT into motivo(motivo_descripcion,motivo_estado)values(MOTIVO,'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_PRODUCTO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_PRODUCTO`(IN PRODUCTO VARCHAR(100),IN IDMARCA INT, IN IDCATEGORIA INT,IN STOCK INT, IN PCOMPRA INT, IN PVENTA INT, IN COD_GENERAL VARCHAR(255), IN PROVEE INT)
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM producto where producto_nombre=PRODUCTO );
IF @CANTIDAD = 0 THEN
	INSERT INTO producto(producto_nombre,marca_id,categoria_id,producto_stock,producto_pcompra,producto_pventa,producto_fregistro,producto_estado,producto_stock_inicial,producto_codigo_general,prove_id) VALUES(PRODUCTO,IDMARCA,IDCATEGORIA,STOCK,PCOMPRA,PVENTA,CURDATE(),'ACTIVO',STOCK,COD_GENERAL,PROVEE);
	
	set @idproducto = LAST_INSERT_ID();
	set @codigoproducto = (select producto_codigo from producto where producto_id =@idproducto);
	
	insert into kardex (kardex_fecha,kardex_tipo,kardex_ingreso,kardex_p_ingreso,kardex_total,producto_id,producto_nombre,producto_codigo,kardex_precio_general) 
	VALUES (CURDATE(),'INICIAL',STOCK,PCOMPRA,STOCK,@idproducto,PRODUCTO,@codigoproducto,PCOMPRA );
	SELECT 1;
ELSE
	SELECT 2;
END IF;

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_PROVEEDOR
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_PROVEEDOR`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_PROVEEDOR`(IN RUC VARCHAR(30),IN RAZON VARCHAR(255),IN DIRECCION VARCHAR(255),IN CELULAR VARCHAR(20))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM proveedor where prove_ruc=RUC);
if @CANTIDAD = 0 THEN
INSERT into proveedor(prove_ruc,prove_razon,prove_direccion,prove_celular,prove_fregistro,prove_estado)values(RUC,RAZON,DIRECCION,CELULAR,CURDATE(),'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_RECEPCION
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_RECEPCION`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_RECEPCION`(IN EQUIPO VARCHAR(20), IN CARACTERISTICAS VARCHAR(255),IN CONCEPTO VARCHAR(255),IN MONTO INT,IN IDCLIENTE INT, IN IDMOTIVO INT,IN ADELANTO DECIMAL (10,2) ,IN DEBE DECIMAL (10,2),IN ACCESORIOS VARCHAR(255), IN FENTREGA DATE,IN MARCAID INT)
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM recepcion WHERE rece_caracteristicas = BINARY CARACTERISTICAS);
IF @CANT = 0 THEN
	INSERT INTO recepcion(cliente_id,rece_equipo,rece_caracteristicas,motivo_id,rece_concepto,rece_monto,rece_fregistro, rece_estado, rece_estatus,rece_adelanto,rece_debe,rece_accesorios,rece_fentrega,marca_id)
	VALUES(IDCLIENTE, EQUIPO, CARACTERISTICAS, IDMOTIVO, CONCEPTO,MONTO,CURDATE(),'POR ENTREGAR','ACTIVO',ADELANTO,DEBE,ACCESORIOS,FENTREGA,MARCAID);
	SELECT 1;
ELSE
	SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_ROL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_ROL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_ROL`(IN ROL VARCHAR(25))
BEGIN
DECLARE CANTIDAD INT;
SET @CANTIDAD:=(SELECT COUNT(*) FROM rol where rol_nombre=ROL);
if @CANTIDAD = 0 THEN
INSERT into rol(rol_nombre,rol_fregistro,rol_estado)values(ROL,CURDATE(),'ACTIVO');
SELECT 1;
ELSE
SELECT 2;
END IF;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_SERVICIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_SERVICIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_SERVICIO`(IN IDRECE INT, IN MONTO INT,IN CONCEPTO VARCHAR(255),IN RESPONSABLE VARCHAR(255),IN COMENTARIO VARCHAR(255))
INSERT INTO servicio(rece_id,servicio_monto,servicio_concepto,servicio_responsable,servicio_comentario,servicio_fregistro,servicio_entrega,servicio_estado) VALUES(IDRECE,MONTO,CONCEPTO,RESPONSABLE,COMENTARIO,CURDATE(),'ENTREGADO','ACTIVO') ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_USUARIOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_USUARIOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_USUARIOS`(IN USUARIO VARCHAR(20), IN CLAVE VARCHAR(255),IN CORREO VARCHAR(255),IN ROL INT,IN RUTA VARCHAR(255))
BEGIN
DECLARE CANT INT;
SET @CANT:=(SELECT COUNT(*) FROM usuario WHERE usu_nombre = BINARY USUARIO);
IF @CANT = 0 THEN
	INSERT INTO usuario(usu_nombre, usu_contrasena, usu_email, rol_id, usu_foto, usu_estado)
	VALUES(USUARIO, CLAVE, CORREO, ROL, RUTA,'ACTIVO');
	
	SELECT 1;
ELSE
	SELECT 2;
END IF;



END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REGISTRAR_VENTA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REGISTRAR_VENTA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REGISTRAR_VENTA`(IN IDCLIENTE INT, IN COMPROBANTE VARCHAR(255), IN SERIE VARCHAR(255), IN NUMERO VARCHAR(255), IN IMPUESTO DECIMAL(10,2),IN TOTAL DECIMAL(10,2),IN IDCOMPROBANTE INT,IN PORCENTAJE DECIMAL(10,2),IN IDUSUARIO INT)
BEGIN
INSERT INTO venta(cliente_id,venta_comprobante,venta_serie,venta_num_comprobante,venta_fregistro,venta_impuesto,venta_total,venta_estado,compro_id,venta_porcentaje,usu_id,venta_hora) VALUES (IDCLIENTE,COMPROBANTE,SERIE,NUMERO,CURDATE(),IMPUESTO,TOTAL,'REGISTRADA',IDCOMPROBANTE,PORCENTAJE,IDUSUARIO,CURRENT_TIME());
SELECT LAST_INSERT_ID();

END ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_GASTO_ANUAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_GASTO_ANUAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_GASTO_ANUAL`(IN ANIO VARCHAR(10))
SELECT  
YEAR(a.gastos_fregistro) as ano,
count(a.gastos_monto) as cant_gastos,
MONTH(a.gastos_fregistro) as numero_mes, 
MONTHname(a.gastos_fregistro) as mes, 
SUM(a.gastos_monto) as gasto,
case month(a.gastos_fregistro) 
WHEN 1 THEN 'Enero'
WHEN 2 THEN  'Febrero'
WHEN 3 THEN 'Marzo' 
WHEN 4 THEN 'Abril' 
WHEN 5 THEN 'Mayo'
WHEN 6 THEN 'Junio'
WHEN 7 THEN 'Julio'
WHEN 8 THEN 'Agosto'
WHEN 9 THEN 'Septiembre'
WHEN 10 THEN 'Octubre'
WHEN 11 THEN 'Noviembre'
WHEN 12 THEN 'Diciembre'
 END mesnombre  
from gastos a
where a.gastos_estado='ACTIVO' and YEAR(a.gastos_fregistro) =ANIO
GROUP BY YEAR(a.gastos_fregistro) ASC,
month(a.gastos_fregistro) ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_GASTO_FECHA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_GASTO_FECHA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_GASTO_FECHA`(IN FINICIO DATE, IN FFIN DATE)
SELECT
	* ,
	(select SUM(gastos_monto) from gastos WHERE gastos_fregistro BETWEEN FINICIO AND FFIN )
FROM
	gastos
	WHERE gastos_fregistro BETWEEN FINICIO AND FFIN ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_GASTO_MES
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_GASTO_MES`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_GASTO_MES`(IN MES VARCHAR(5))
SELECT
	gastos.gastos_id, 
	gastos.gastos_descripcion, 
	gastos.gastos_monto, 
	gastos.gastos_responsable, 
	gastos.gastos_fregistro, 
	gastos.gastos_estado
FROM
	gastos
	WHERE gastos.gastos_estado ='ACTIVO' 
	and (select MONTH(gastos_fregistro))=MES
		and YEAR(gastos_fregistro)=YEAR(CURDATE())
		ORDER BY gastos_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_GASTO_TOTAL_ANUAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_GASTO_TOTAL_ANUAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_GASTO_TOTAL_ANUAL`()
SELECT 
YEAR(gastos_fregistro) as ano,
SUM(gastos_monto) as total_gasto_ano 
FROM gastos
where gastos_estado='ACTIVO'  GROUP BY YEAR(gastos_fregistro) desc ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_PRODUCTO_EN_SAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_PRODUCTO_EN_SAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_PRODUCTO_EN_SAL`()
SELECT
	kardex.kardex_id,
	kardex.kardex_tipo ,
	kardex.producto_id, 
	kardex.producto_codigo as codigo, 
	kardex.producto_nombre as nombre, 
	kardex.kardex_p_ingreso as precio, 
	IFNULL(SUM(kardex_ingreso),0) as ingresos,
	IFNULL(sum(kardex_salida),0) as salidas,
IFNULL((SUM(kardex_ingreso) - sum(kardex_salida) ),SUM(kardex_ingreso)) as stock_actual
FROM
	kardex
	where kardex_tipo IN ('INICIAL','INGRESO','SALIDA')
	GROUP BY producto_id ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_SERVICIO_ANUAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_SERVICIO_ANUAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_SERVICIO_ANUAL`(IN ANIO VARCHAR(10))
SELECT  
YEAR(s.servicio_fregistro) as ano,
count(s.servicio_fregistro) as cant_servicio,
MONTH(s.servicio_fregistro) as numero_mes, 
MONTHname(s.servicio_fregistro) as mes, 
SUM(s.servicio_monto) as monto_servicio,
case month(s.servicio_fregistro) 
WHEN 1 THEN 'Enero'
WHEN 2 THEN  'Febrero'
WHEN 3 THEN 'Marzo' 
WHEN 4 THEN 'Abril' 
WHEN 5 THEN 'Mayo'
WHEN 6 THEN 'Junio'
WHEN 7 THEN 'Julio'
WHEN 8 THEN 'Agosto'
WHEN 9 THEN 'Septiembre'
WHEN 10 THEN 'Octubre'
WHEN 11 THEN 'Noviembre'
WHEN 12 THEN 'Diciembre'
 END mesnombre  
from servicio s
where YEAR(s.servicio_fregistro) =ANIO
GROUP BY YEAR(s.servicio_fregistro) ASC,
month(s.servicio_fregistro) ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_SERVICIO_MES
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_SERVICIO_MES`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_SERVICIO_MES`(IN MES VARCHAR(5))
SELECT
	servicio.servicio_id, 
	servicio.rece_id, 
	recepcion.cliente_id, 
	cliente.cliente_nombres, 
	CONCAT_WS(' - ',recepcion.rece_equipo,recepcion.rece_concepto) as concepto, 
	recepcion.rece_monto, 
	recepcion.rece_estado, 
	servicio.servicio_monto, 
	servicio.servicio_concepto, 
	servicio.servicio_responsable, 
	servicio.servicio_comentario, 
	servicio.servicio_entrega,
	servicio.servicio_fregistro,
	servicio.servicio_estado
FROM
	servicio
	INNER JOIN
	recepcion
	ON 
		servicio.rece_id = recepcion.rece_id
	INNER JOIN
	cliente
	ON 
		recepcion.cliente_id = cliente.cliente_id 
		WHERE MONTH(servicio_fregistro)=MES
		and YEAR(servicio_fregistro)=YEAR(CURDATE())
		ORDER BY servicio.servicio_fregistro DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_VENTA_ANIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_VENTA_ANIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_VENTA_ANIO`(IN ANIO VARCHAR(10))
SELECT 
YEAR(v.venta_fregistro) as ano, 
MONTH(v.venta_fregistro) as numero_mes, 
MONTHname(v.venta_fregistro) as mes,
count(v.venta_total) as cant_fact,
SUM(v.venta_total) as total,
case month(v.venta_fregistro) 
WHEN 1 THEN 'Enero'
WHEN 2 THEN  'Febrero'
WHEN 3 THEN 'Marzo' 
WHEN 4 THEN 'Abril' 
WHEN 5 THEN 'Mayo'
WHEN 6 THEN 'Junio'
WHEN 7 THEN 'Julio'
WHEN 8 THEN 'Agosto'
WHEN 9 THEN 'Septiembre'
WHEN 10 THEN 'Octubre'
WHEN 11 THEN 'Noviembre'
WHEN 12 THEN 'Diciembre'
 END mesnombre 
FROM venta v
where venta_estado='REGISTRADA' and YEAR(v.venta_fregistro) =ANIO
GROUP BY YEAR(v.venta_fregistro) desc,
month(v.venta_fregistro) ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_VENTA_ANULADA
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_VENTA_ANULADA`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_VENTA_ANULADA`(IN MES VARCHAR(5),IN ANIO VARCHAR(10))
SELECT
	venta.venta_id, 
	MONTH(venta_fregistro) as numero_mes, 
	cliente.cliente_nombres, 
	
	CONCAT_WS(' - ',venta.venta_comprobante, venta.venta_serie,venta.venta_num_comprobante) AS comprobante, 
	venta.venta_total, 
	venta.venta_fregistro, 
	venta.venta_estado, 
	venta.compro_id, 
	venta.usu_id, 
	usuario.usu_nombre
FROM
	venta
	INNER JOIN
	cliente
	ON 
		venta.cliente_id = cliente.cliente_id
	INNER JOIN
	comprobante
	ON 
		venta.compro_id = comprobante.compro_id
	INNER JOIN
	usuario
	ON 
		venta.usu_id = usuario.usu_id
		WHERE venta.venta_fregistro and venta_estado='ANULADA' 
		and (select MONTH(venta_fregistro))=MES 
		and YEAR(venta_fregistro)=ANIO
		ORDER BY venta_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_VENTA_GENERAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_VENTA_GENERAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_VENTA_GENERAL`()
SELECT 
YEAR(v.venta_fregistro) as ano, 
MONTH(v.venta_fregistro) as numero_mes, 
MONTHname(v.venta_fregistro) as mes,
count(v.venta_total) as cant_fact,
SUM(v.venta_total) as total,
case month(v.venta_fregistro) 
WHEN 1 THEN 'Enero'
WHEN 2 THEN  'Febrero'
WHEN 3 THEN 'Marzo' 
WHEN 4 THEN 'Abril' 
WHEN 5 THEN 'Mayo'
WHEN 6 THEN 'Junio'
WHEN 7 THEN 'Julio'
WHEN 8 THEN 'Agosto'
WHEN 9 THEN 'Septiembre'
WHEN 10 THEN 'Octubre'
WHEN 11 THEN 'Noviembre'
WHEN 12 THEN 'Diciembre'
 END mesnombre 
FROM venta v
where venta_estado='REGISTRADA' 
GROUP BY YEAR(v.venta_fregistro) desc,
month(v.venta_fregistro) ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_VENTA_MES
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_VENTA_MES`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_VENTA_MES`(IN MES VARCHAR(5),IN ANIO VARCHAR(10))
SELECT
	venta.venta_id, 
	cliente.cliente_nombres, 
	 
	CONCAT_WS(' - ',venta.venta_comprobante,venta.venta_serie,venta.venta_num_comprobante) AS comprobante, 
	venta.venta_total, 
	venta.venta_fregistro, 
	venta.venta_estado,
	COUNT(detalle_venta.vdetalle_cantidad) AS cant_prod, 
	venta.compro_id
	
FROM
	venta
	INNER JOIN
	cliente
	ON 
		venta.cliente_id = cliente.cliente_id
	INNER JOIN
	comprobante
	ON 
		venta.compro_id = comprobante.compro_id
	INNER JOIN
	detalle_venta
	ON 
		venta.venta_id = detalle_venta.venta_id
		
		WHERE venta.venta_fregistro and venta_estado='REGISTRADA' 
		and (select MONTH(venta_fregistro))=MES 
		and YEAR(venta_fregistro)=ANIO
		GROUP BY venta.venta_id DESC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_REPORTE_VENTA_TOTAL
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_REPORTE_VENTA_TOTAL`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_REPORTE_VENTA_TOTAL`()
SELECT 
YEAR(venta_fregistro) as ano,
count(venta_total) as cant_venta_ano,
SUM(venta_total) as total_venta_ano
FROM venta
where venta_estado='REGISTRADA' GROUP BY YEAR(venta_fregistro) desc ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_SELECT_PERMISOS
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_SELECT_PERMISOS`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_SELECT_PERMISOS`()
SELECT * from permiso
ORDER BY idpermiso ASC ;; 
DELIMITER ; 
-- ----------------------------
-- Procedure structure for SP_VERIFICAR_USUARIO
-- ----------------------------
 
DROP PROCEDURE IF EXISTS `SP_VERIFICAR_USUARIO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` PROCEDURE `SP_VERIFICAR_USUARIO`(IN USUARIO VARCHAR(250))
SELECT
	usuario.usu_id, 
	usuario.usu_nombre, 
	usuario.usu_contrasena, 
	usuario.rol_id, 
	usuario.usu_estado, 
	usuario.usu_email, 
	usuario.usu_foto, 
	rol.rol_nombre
FROM
	usuario
	INNER JOIN
	rol
	ON 
		usuario.rol_id = rol.rol_id
where usu_nombre = BINARY USUARIO ;; 
DELIMITER ; 

-- ============================================== TRIGGERS ================================================
-- ----------------------------
-- Trigger structure for TR_STOCK_PRODUCTO
-- ----------------------------
 
DROP TRIGGER IF EXISTS `TR_STOCK_PRODUCTO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `TR_STOCK_PRODUCTO` BEFORE INSERT ON `detalle_venta` FOR EACH ROW BEGIN
DECLARE STOCKACTUAL INT;
SET @STOCKACTUAL:=(SELECT producto_stock FROM producto WHERE producto_id=new.producto_id);
UPDATE producto SET
producto_stock=@STOCKACTUAL-new.vdetalle_cantidad
where producto_id=new.producto_id;
END ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for Generar_codigo
-- ----------------------------
 
DROP TRIGGER IF EXISTS `Generar_codigo`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `Generar_codigo` BEFORE INSERT ON `producto` FOR EACH ROW begin
	declare siguiente_codigo int;
    set siguiente_codigo = (Select ifnull(max(convert(producto_id, signed integer)), 0) from producto) + 1;
    set new.producto_codigo = concat('P', LPAD( siguiente_codigo, 4, '0'));
end ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for TR_ESTADO
-- ----------------------------
 
DROP TRIGGER IF EXISTS `TR_ESTADO`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `TR_ESTADO` BEFORE INSERT ON `servicio` FOR EACH ROW UPDATE recepcion SET
rece_estado = "ENTREGADO"
WHERE rece_id= new.rece_id ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for TR_ELIMINAR
-- ----------------------------
 
DROP TRIGGER IF EXISTS `TR_ELIMINAR`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `TR_ELIMINAR` BEFORE DELETE ON `servicio` FOR EACH ROW UPDATE recepcion SET
rece_estado = "POR ENTREGAR"
WHERE rece_id=old.rece_id ;; 
DELIMITER ; 
-- ----------------------------
-- Trigger structure for tr_numero_compro
-- ----------------------------
 
DROP TRIGGER IF EXISTS `tr_numero_compro`;
DELIMITER ;; 
CREATE DEFINER=`root`@`localhost` TRIGGER `tr_numero_compro` BEFORE INSERT ON `venta` FOR EACH ROW BEGIN
DECLARE NUMCOMPRO INT;
SET @NUMCOMPRO:=(SELECT compro_numero FROM comprobante WHERE compro_id=new.compro_id);
UPDATE comprobante SET
compro_numero=@NUMCOMPRO+0001
where compro_id=new.compro_id;
END ;; 
DELIMITER ; 
}*/
-- ================================== END DATABASE prueba ========================================

 
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
